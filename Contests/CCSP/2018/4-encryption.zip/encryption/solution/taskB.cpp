#include <stdio.h>
#include <string.h>

unsigned int s[16] = {12, 5, 6, 11, 9, 0, 10, 13, 3, 14, 15, 8, 4, 7, 1, 2};
unsigned int p[16] = {12, 1, 9, 2, 0, 11, 7, 3, 4, 15, 8, 5, 14, 13, 10, 6};
unsigned int mask[16];
char str[10];
char str1[33];
char str2[33];

void print_bs(unsigned int tmp, int len)
{
    int num[32] = {0};
    for(int i=0; i<len; i++)
    {
        num[i] = tmp & 1;
        tmp >>= 1;
    }
    for(int i=len-1; i>=0; i--)
        printf("%d",num[i]);
    printf("\n");
}

unsigned int bs_to_int(char* str)
{
    unsigned int tmp = 0;
    int i=0;
    while(str[i]!=0)
    {
        tmp <<= 1;
        if(str[i]=='1') tmp |= 1;
        i++;
    }
    return tmp;
}

unsigned int encrypt(unsigned int state, unsigned int key)
{
    key = (key << 4) | ((key & 15) ^ ((key >> 4) & 15) ^ ((key >> 8) & 15));
    for(int i=0; i<16; i++)
    {
        unsigned int tmp0 = state >> 16;
        unsigned int tmp1 = state & 65535;
        state = tmp0 | (tmp1 << 16);
        tmp1 ^= key;
        for(int j=0; j<4; j++)
            tmp1 = (tmp1 >> 4) | (s[tmp1 & 15] << 12);
        tmp0 = 0;
        for(int j=0; j<16; j++)
        {
            tmp0 <<= 1;
            if((mask[p[j]] & tmp1)!=0) tmp0 |= 1;
        }
        state ^= tmp0;
        key = (key << 1) & 65535 | (key >> 15);
    }
    return (((state & 65535) << 16) | (state >> 16));
}

void init_mask()
{
    unsigned int tmp = 1;
    for(int i=15; i>=0; i--)
    {
        mask[i] = tmp;
        tmp <<= 1;
    }
}

int brute(unsigned int text1, unsigned int text2, unsigned int *key1, unsigned int * key2)
{
    for(unsigned int i=0; i<4096; i++)
        for(unsigned int j=0; j<4096; j++)
            if(encrypt(encrypt(text1,i),j)==text2)
            {
                *key1 = i;
                *key2 = j;
                return 1;
            }
    return 0;
}

int main()
{
    scanf("%s",str);
    if(strcmp(str,"TASKB")==0)
    {
        init_mask();
        scanf("%s%s",str1,str2);
        unsigned int text1 = bs_to_int(str1);
        unsigned int text2 = bs_to_int(str2);
        unsigned int key1,key2;
        if(brute(text1,text2,&key1,&key2)==1)
        {
            printf("YES\n");
            print_bs(key1,12);
            print_bs(key2,12);
        }
        else printf("NO\n");
    }
    return 0;
}
