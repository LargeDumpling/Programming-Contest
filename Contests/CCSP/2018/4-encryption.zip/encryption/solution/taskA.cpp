#include <iostream>
using namespace std;
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <stack>

#define MAXN 10
#define PLEN 64
#define SLEN 8
#define MAX_TOT_LINE 10000

struct ptable_type{
    int input_size,output_size;
    int element[PLEN];
};

struct sbox_type{
    int input_size,output_size;
    int element[1<<SLEN];
};

struct lex_type{
	string name;
	int type;
	unsigned long long value;
};

struct bs_var_type{
	string name;
    int len;
	unsigned long long value;
	vector<bs_var_type*> ch;
};

struct expr_type{
	int id,type,len;
	unsigned long long value;
	vector<int> bs_varp;
	expr_type *expr1, *expr2;
};

struct gra_type{
	int type, var, value, jmp;
	vector<int> bs_varp;
	expr_type* expr;
	int st, ed; //lex[st] .. lex[ed]
};

int n,m;
ptable_type ptable[MAXN];
sbox_type sbox[MAXN];

string task_id;
string code; //store all characters of the code
int loop_var[26];
vector<bs_var_type> bs_var;
vector<lex_type> lex;
vector<gra_type> gra;
stack<int> loop_pos;
vector<expr_type*> expr_ptr;

bool bs_to_num(const string& str, unsigned long long& num)
{
    if(str.empty() || str.length()>PLEN) return false;
    for(int i=0; i<str.length(); i++)
        if(str[i]!='0' && str[i]!='1') return false;
    num = 0;
    for(int i=0; i<str.length(); i++)
        num = (num << 1) + str[i] - '0';
    return true;
}

bool num_to_bs(const unsigned long long& num, string& str, int size = PLEN)
{
    if(size<1 || size>PLEN) return false;
    str.clear();
    unsigned long long tmp = 1ull << (size - 1);
    while(tmp)
    {
        if(num&tmp) str.push_back('1');
        else str.push_back('0');
        tmp = tmp >> 1;
    }
    return true;
}

string int_to_str(int i)
{
    string str;
    stack<char> s;
    char ch;
    if(i==0)
    {
        str = "0";
        return str;
    }
    if(i<0)
    {
        str.push_back('-');
        i = -i;
    }
    while(i>0)
    {
        ch = '0' + (i % 10);
        s.push(ch);
        i /= 10;
    }
    while(!s.empty())
    {
        str.push_back(s.top());
        s.pop();
    }
    return str;
}

void cerr_lex(int l, int r)
{
    cerr << l << "\t" << r << endl;
    for(int i=l; i<=r; i++)
    {
        if(lex[i].name=="\n") cerr << "\\n";
        else cerr << lex[i].name;
        cerr << ' ';
    }
    cerr << endl;
}

void output_lex(int i)
{
    cout << i << '\t';
    if(lex[i].name=="\n") cout << "\\n";
    else cout << lex[i].name;
    cout << '\t' << lex[i].type << '\t' << lex[i].value << endl;
}

void output_lex()
{
    cout << "LEX:\tname\ttype\tvalue" << endl;
    for(int i=0; i<lex.size(); i++)
        output_lex(i);
    cout << "------" << endl << endl;
}

void output_bs_var(bs_var_type* ptr)
{
    if(ptr==NULL) return;
    string str;
    num_to_bs(ptr->value,str,ptr->len);
    cout << ptr->name << '\t' << ptr->len << '\t' << str << '\t' << ptr->ch.size() << endl;
    for(int i=0; i<ptr->ch.size(); i++)
        output_bs_var(ptr->ch[i]);
}

void output_bs_var(int i)
{
    output_bs_var(&bs_var[i]);
}

void output_bs_var()
{
    cout << "BS_VAR:\tlen\tvalue\tch_size" << endl;
    for(int i=0; i<bs_var.size(); i++)
        output_bs_var(&bs_var[i]);
    cout << "------" << endl << endl;
}

void output_gra(int i)
{
    for(int j=gra[i].st; j<=gra[i].ed; j++)
    {
        if(lex[j].name=="\n") cout << "\\n";
        else cout << lex[j].name;
        cout << ' ';
    }
    cout << '\t' << gra[i].st << '\t' << gra[i].ed << '\t';
    cout << gra[i].type << '\t' << gra[i].var << '\t' << gra[i].value << '\t' << gra[i].jmp << '\t';
    if(gra[i].expr!=NULL) cout << gra[i].expr->id << '\t';
    else cout << "NULL\t";
    for(int j=0; j<gra[i].bs_varp.size(); j++)
        cout << gra[i].bs_varp[j] << '\t';
    cout << endl;
}

void output_gra()
{
    cout << "GRA:\tst\ted\ttype\tvar\tvalue\tjmp\texpr\tbs_varp" << endl;
    for(int i=0; i<gra.size(); i++)
        output_gra(i);
    cout << "------" << endl << endl;
}

void output_expr(int i)
{
    cout << expr_ptr[i]->id << '\t';
    if(expr_ptr[i]->expr1!=NULL) cout << expr_ptr[i]->expr1->id << '\t';
    else cout << "NULL\t";
    if(expr_ptr[i]->expr2!=NULL) cout << expr_ptr[i]->expr2->id << '\t';
    else cout << "NULL\t";
    cout << expr_ptr[i]->type << '\t';
    cout << expr_ptr[i]->value << '\t';
    for(int j=0; j<expr_ptr[i]->bs_varp.size(); j++)
        cout << expr_ptr[i]->bs_varp[j] << '\t';
    cout << endl;
}

void output_expr()
{
    cout << "EXPR:\tlch\trch\ttype\tvalue\tbs_varp" << endl;
    for(int i=0; i<expr_ptr.size(); i++)
        output_expr(i);
    cout << "------" << endl << endl;
}


void read_ptable()
{
    for(int i=0; i<n; i++)
    {
        int a,b,x;
        cin >> a >> b;
        if(a<1 || a>PLEN || b<1 || b>PLEN)
        {
            cerr << "P SIZE ERROR" << endl;
            exit(0);
        }
        ptable[i].input_size = a;
        ptable[i].output_size = b;
        for(int j=0; j<b; j++)
        {
            cin >> x;
            if(x<0 || x>a)
            {
                cerr << "P ELEMENT ERROR" << endl;
                exit(0);
            }
            ptable[i].element[j] = x;
        }
    }
}

void read_sbox()
{
    for(int i=0; i<m; i++)
    {
        int c,d,x;
        cin >> c >> d;
        if(c<1 || c>SLEN || d<1 || d>SLEN)
        {
            cerr << "S SIZE ERROR" << endl;
            exit(0);
        }
        sbox[i].input_size = c;
        sbox[i].output_size = d;
        for(int j=0; j<(1<<c); j++)
        {
            cin >> x;
            if(x<0 || x>(1<<d))
            {
                cerr << "S ELEMENT ERROR" << endl;
                exit(0);
            }
            sbox[i].element[j] = x;
        }
    }
}

void read_code()
{
    char ch;
    while(ch!='\n') cin.get(ch);
    bool meet_end = false;
    while(true)
    {
        cin.get(ch);
        code.push_back(ch);
        if(ch=='D') meet_end = true;
        if(ch=='L') meet_end = false;
        if(ch=='\n' && meet_end) break;
    }
}

void get_bs_var(int l, int r, unsigned long long& value, vector<int>& bs_varp)
{
    if(l>r || lex[l].type!=2 || (r-l)%3!=0)
    {
        cerr << "BS_VAR ERROR:\t";
        cerr_lex(l,r);
        exit(0);
    }
    value = lex[l].value;
    int i = l + 1;
    while(i<r)
    {
        if(lex[i].name!="[" || lex[i+2].name!="]" || (lex[i+1].type!=1 && lex[i+1].type!=3))
        {
            cerr << "BS_VAR ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        if(lex[i+1].type==1)
        {
            bs_varp.push_back((int)(lex[i+1].value)-26);   // 0..25 -> -26..-1
        }
        else if(lex[i+1].type==3)
        {
            bs_varp.push_back(lex[i+1].value);  // 0..63
        }
        i += 3;
    }
}

int find_bs(string &name)
{
    for(int i=0; i<bs_var.size(); i++)
        if(bs_var[i].name==name)
            return i;
    return -1;
}

void lex_ana()
{
    char type5[7] = {'=', '+', '(', ')', '[', ']', '\n'};
    string type0[8] = {"BEGIN", "END", "P", "S", "LOOP", "ENDLOOP", "SPLIT", "MERGE"};
    int i = 0, j;
    string str;
    lex_type tmp;
    bool meet_begin = false;
    while(i<code.length())
    {
        while(code[i]==',' || code[i]==' ' || code[i]=='\t') i++;
        str.push_back(code[i]);
        i++;
        if(str[0]>='A' && str[0]<='Z')  //type 0
        {
            while(i<code.length() && code[i]>='A' && code[i]<='Z')
            {
                str.push_back(code[i]);
                i++;
            }
            for(j=0; j<8; j++)
                if(str==type0[j]) break;
            if(j==8)
            {
                cerr << "LEX ERROR: " << str << endl;
                exit(0);
            }
            if(j==0) meet_begin = true;
            tmp.name = str;
            tmp.type = 0;
            tmp.value = j;
            lex.push_back(tmp);
        }
        else if(str[0]>='a' && str[0]<='z') //type 1 or 2
        {
            while(i<code.length() && code[i]>='a' && code[i]<='z')
            {
                str.push_back(code[i]);
                i++;
            }
            if(str.length()==1) //type 1
            {
                tmp.name = str;
                tmp.type = 1;
                tmp.value = str[0] - 'a';
                lex.push_back(tmp);
            }
            else if(str.length()>1 && str.length()<=10) //type 2
            {
                j = find_bs(str);
                if(j==-1)   // new bs_var
                {
                    if(meet_begin)
                    {
                        cerr << "LEX ERROR: undefined bs_var " << str << endl;
                        exit(0);
                    }
                    j = bs_var.size();
                    bs_var_type beta;
                    beta.name = str;
                    beta.len = 0;
                    beta.value = 0;
                    bs_var.push_back(beta);
                }
                else if(!meet_begin)
                {
                    cerr << "LEX ERROR: redefine bs_var " << str << endl;
                    exit(0);
                }
                tmp.name = str;
                tmp.type = 2;
                tmp.value = j;
                lex.push_back(tmp);
            }
            else
            {
                cerr << "LEX ERROR: size > 10 " << str << endl;
                exit(0);
            }
        }
        else if(str[0]>='0' && str[0]<='9') //type 3
        {
            while(i<code.length() && code[i]>='0' && code[i]<='9')
            {
                str.push_back(code[i]);
                i++;
            }
            if(str.length()>5)
            {
                cerr << "LEX ERROR: " << str << endl;
                exit(0);
            }
            tmp.name = str;
            tmp.type = 3;
            tmp.value = str[0] - '0';
            for(j=1; j<str.length(); j++)
            {
                tmp.value = tmp.value * 10 + str[j] - '0';
            }
            if(tmp.value>10000)
            {
                cerr << "LEX ERROR: " << str << endl;
                exit(0);
            }
            lex.push_back(tmp);
        }
        else if(str[0]=='\"')   //type 4
        {
            while(i<code.length() && code[i]>='0' && code[i]<='1')
            {
                str.push_back(code[i]);
                i++;
            }
            if(i<code.length())
            {
                str.push_back(code[i]);
                i++;
            }
            int k = str.length();
            if(k<=2 || k-2>PLEN || str[k-1]!='\"')
            {
                cerr << "LEX ERROR: " << str << endl;
                exit(0);
            }
            tmp.name = str;
            tmp.type = 4;
            tmp.value = 0;
            for(j=1; j<k-1; j++)
            {
                tmp.value = (tmp.value << 1) + str[j] - '0';
            }
            lex.push_back(tmp);
        }
        else    //type 5
        {
            for(j=0; j<7; j++)
                if(str[0]==type5[j]) break;
            if(j==7)
            {
                cerr << "LEX ERROR: " << str << endl;
                exit(0);
            }
            tmp.name = str;
            tmp.type = 5;
            tmp.value = j;
            lex.push_back(tmp);
        }
        str.clear();
    }
}

void init_bs_var()
{
    int i = 0;
    while(lex[i].name!="BEGIN")
    {
        if(lex[i].type!=2 || lex[i+1].name!="(" || lex[i+2].type!=3 || lex[i+3].name!=")" || lex[i+4].name!="\n")
        {
            cerr << "INIT BS_VAR ERROR" << endl;
            for(int j=0; j<5; j++)
                output_lex(i+j);
            exit(0);
        }
        int tmp = lex[i].value;
        int beta = lex[i+2].value;
        if(beta<1 || beta>PLEN)
        {
            cerr << "INIT BS_VAR ERROR: length is not in [1, " << PLEN << "]" << endl;
            for(int j=0; j<5; j++)
                output_lex(i+j);
            exit(0);
        }
        bs_var[tmp].len = beta;
        bs_var[tmp].value = 0;
        bs_var[tmp].ch.clear();
        i += 5;
    }
    if(lex.size()<10 || lex[0].name!="state" || lex[5].name!="key")
    {
        cerr << "INIT BS_VAR ERROR" << endl;
        if(lex.size()>=10)
        {
            output_lex(0);
            output_lex(5);
        }
        exit(0);
    }
}

expr_type* generate_expr(int l, int r)
{
    if(l>r) return NULL;
    expr_type* ptr = new expr_type;
    ptr->id = expr_ptr.size();
    expr_ptr.push_back(ptr);
    ptr->expr1 = NULL;
    ptr->expr2 = NULL;
    ptr->value = 0;
    ptr->len = 0;   // only for bs const "..."
    int num = 0;
    int i = l;
    while(i<=r)
    {
        if(lex[i].name=="(") num++;
        if(lex[i].name==")") num--;
        if(num<0) { cerr_lex(l,r); return NULL; }
        if(lex[i].name=="+" && num==0) break;
        i++;
    }
    if(i<=r)
    {
        ptr->type = 2;
        ptr->expr1 = generate_expr(l,i-1);
        if(ptr->expr1==NULL) { cerr_lex(l,r); return NULL; }
        ptr->expr2 = generate_expr(i+1,r);
        if(ptr->expr2==NULL) { cerr_lex(l,r); return NULL; }
        return ptr;
    }
    if(lex[l].name=="P" || lex[l].name=="S")
    {
        if(lex[l].name=="P") ptr->type = 3;
        else ptr->type = 4;
        if(l+4>=r || lex[l+1].name!="[" || lex[l+3].name!="]" || lex[l+4].name!="(" || lex[r].name!=")")
            { cerr_lex(l,r); return NULL; }
        if(lex[l+2].type==1)
        {
            ptr->value = lex[l+2].value - 26;
        }
        else if(lex[l+2].type==3)
        {
            ptr->value = lex[l+2].value;
        }
        else { cerr_lex(l,r); return NULL; }
        ptr->expr1 = generate_expr(l+5,r-1);
        if(ptr->expr1==NULL) { cerr_lex(l,r); return NULL; }
        return ptr;
    }
    if(lex[l].type==4)
    {
        if(l!=r) { cerr_lex(l,r); return NULL; }
        ptr->type = 1;
        ptr->len = lex[l].name.length() - 2;
        ptr->value = lex[l].value;
        return ptr;
    }
    if(lex[l].type==2)
    {
        ptr->type = 0;
        get_bs_var(l,r,ptr->value,ptr->bs_varp);
        return ptr;
    }
    cerr << l << '\t' << r << endl;
    for(int pcz=l; pcz<=r; pcz++) cerr<<lex[pcz].name;
    cerr<<endl;
    return NULL;
}

void generate_gra(int l, int r)
{
    gra_type tmp;
    tmp.st = l;
    tmp.ed = r;
    tmp.var = tmp.value = tmp.jmp = 0;
    tmp.expr = NULL;
    if(lex[l].name=="BEGIN")
    {
        if(r!=l+1)
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        tmp.type = 0;
        tmp.value = 0;
    }
    else if(lex[l].name=="END")
    {
        if(r!=l+1)
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        tmp.type = 0;
        tmp.value = 1;
    }
    else if(lex[l].name=="LOOP")
    {
        if(r!=l+4 || lex[l+1].type!=1 || lex[l+2].type!=3 || lex[l+3].type!=3 || lex[l+2].value>lex[l+3].value)
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        tmp.type = 2;
        tmp.var = lex[l+1].value;
        tmp.value = lex[l+2].value;
        tmp.jmp = lex[l+3].value;
        loop_pos.push(gra.size());
    }
    else if(lex[l].name=="ENDLOOP")
    {
        if(r!=l+1)
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        int pos = loop_pos.top();
        loop_pos.pop();
        tmp.type = 3;
        tmp.var = gra[pos].var;
        tmp.value = gra[pos].jmp;
        gra[pos].jmp = 0;
        tmp.jmp = pos + 1;
    }
    else if(lex[l].name=="SPLIT")
    {
        if(r-l<5 || lex[l+1].name!="(" || lex[r-1].name!=")" || lex[r-2].type!=3)
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        tmp.type = 4;
        tmp.value = lex[r-2].value;
        unsigned long long beta;
        get_bs_var(l+2,r-3,beta,tmp.bs_varp);
        tmp.var = beta;
    }
    else if(lex[l].name=="MERGE")
    {
        if(r-l<4 || lex[l+1].name!="(" || lex[r-1].name!=")")
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        tmp.type = 5;
        unsigned long long beta;
        get_bs_var(l+2,r-2,beta,tmp.bs_varp);
        tmp.var = beta;
    }
    else if(lex[l].type==2)   //assignment statement
    {
        int i = l;
        while(i<=r && lex[i].name!="=") i++;
        if(i==l || i>=r-1)
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
        tmp.type = 1;
        unsigned long long beta;
        get_bs_var(l,i-1,beta,tmp.bs_varp);
        tmp.var = beta;
        tmp.expr = generate_expr(i+1,r-1);
        if(tmp.expr==NULL)
        {
            cerr << "GRA ERROR:\t";
            cerr_lex(l,r);
            exit(0);
        }
    }
    else
    {
        cerr << "GRA ERROR:\t";
        cerr_lex(l,r);
        exit(0);
    }
    gra.push_back(tmp);
}

void gra_ana()
{
    int i = 0, j;
    for(i=0; lex[i].name!="BEGIN"; i++);
    while(i<lex.size())
    {
        for(j=i; lex[j].name!="\n"; j++);
        generate_gra(i,j);
        i = j + 1;
    }
}

bs_var_type* find_bs_varp(long long pos, const vector<int>& bs_varp)
{
    bs_var_type* ptr = &bs_var[pos];
    for(int i=0; i<bs_varp.size(); i++)
    {
        int j = bs_varp[i];
        if(j<0) j = loop_var[j + 26];
        if(j<0 || j>=ptr->ch.size())
        {
            cerr << "bs_varp error" << endl;
            output_bs_var(pos);
            exit(0);
        }
        ptr = ptr->ch[j];
    }
    return ptr;
}

unsigned long long cal_expr(expr_type* ptr, int& len)
{
    if(ptr==NULL)
    {
        cerr << "VOID EXPR" << endl;
        exit(0);
    }
    if(ptr->type==0)
    {
        bs_var_type* bsptr = find_bs_varp(ptr->value, ptr->bs_varp);
        if(bsptr->ch.size()!=0)
        {
            cerr << "use high level bs var" << endl;
            exit(0);
        }
        len = bsptr->len;
        return bsptr->value;
    }
    else if(ptr->type==1)
    {
        len = ptr->len;
        return ptr->value;
    }
    else if(ptr->type==2)
    {
        unsigned long long tmp;
        int len2;
        tmp = cal_expr(ptr->expr1,len) ^ cal_expr(ptr->expr2,len2);
        if(len!=len2)
        {
            cerr << "expr + expr : length not match" << endl;
            exit(0);
        }
        return tmp;
    }
    else if(ptr->type==3)
    {
        unsigned long long tmp = cal_expr(ptr->expr1,len);
        long long j = ptr->value;
        if(j<0) j = loop_var[j+26];
        if(j<0 || j>=n)
        {
            cerr << "WRONG Ptable ID" << endl;
            exit(0);
        }
        if(len!=ptable[j].input_size)
        {
            cerr << "P[](expr) : length not match" << endl;
            exit(0);
        }
        len = ptable[j].output_size;
        string sin,sout;
        num_to_bs(tmp,sin,ptable[j].input_size);
        for(int i=0; i<ptable[j].output_size; i++)
            sout.push_back(sin[ptable[j].element[i]]);
        bs_to_num(sout,tmp);
        return tmp;
    }
    else if(ptr->type==4)
    {
        unsigned long long tmp = cal_expr(ptr->expr1,len);
        long long j = ptr->value;
        if(j<0) j = loop_var[j+26];
        if(j<0 || j>=m)
        {
            cerr << "WRONG Sbox ID" << endl;
            exit(0);
        }
        if(len!=sbox[j].input_size)
        {
            cerr << "S[](expr) : length not match" << endl;
            exit(0);
        }
        len = sbox[j].output_size;
        if(tmp>=(1<<sbox[j].input_size))
        {
            cerr << "wrong sbox input" << endl;
            exit(0);
        }
        return sbox[j].element[tmp];
    }
    else
    {
        cerr << "EXPR TYPE ERROR:" << endl;
        output_expr(ptr->id);
        exit(0);
    }
}

unsigned long long encrypt(unsigned long long state, unsigned long long key)
{
    int tot_line = 0, now = 0;
    while(true)
    {
        //output_bs_var();
        //output_gra(now);
        tot_line++;
        if(tot_line>MAX_TOT_LINE || now<0 || now>=gra.size())
        {
            cerr << "RUNTIME ERROR" << endl;
            exit(0);
        }
        if(gra[now].type==0)
        {
            if(gra[now].value==0)   //BEGIN
            {
                bs_var[0].value = state;
                bs_var[1].value = key;
                for(int i=2; i<bs_var.size(); i++)
                    bs_var[i].value = 0;
                now++;
            }
            else
            {
                //cerr << tot_line << endl;
                for(int i=0; i<bs_var.size(); i++)
                    if(bs_var[i].ch.size()>0)
                {
                    cerr << "NOT MERGE " << bs_var[i].name << endl;
                    exit(0);
                }
                return bs_var[0].value;   //END
            }
        }
        else if(gra[now].type==1)
        {
            bs_var_type* ptr = find_bs_varp(gra[now].var,gra[now].bs_varp);
            if(ptr->ch.size()!=0)
            {
                cerr << "use high level bs var" << endl;
                output_gra(now);
                exit(0);
            }
            int len;
            ptr->value = cal_expr(gra[now].expr,len);
            if(len!=ptr->len)
            {
                cerr << "length not match" << endl;
                output_gra(now);
                exit(0);
            }
            now++;
        }
        else if(gra[now].type==2)
        {
            loop_var[gra[now].var] = gra[now].value;
            now++;
        }
        else if(gra[now].type==3)
        {
            loop_var[gra[now].var]++;
            if(loop_var[gra[now].var]>gra[now].value) now++;
            else now = gra[now].jmp;
        }
        else if(gra[now].type==4)
        {
            bs_var_type* ptr = find_bs_varp(gra[now].var,gra[now].bs_varp);
            if(ptr->ch.size()!=0)
            {
                cerr << "use high level bs var" << endl;
                output_gra(now);
                exit(0);
            }
            int tmp = gra[now].value;
            if(tmp<=1 || ptr->len%tmp!=0)
            {
                cerr << "WRONG SPLIT NUMBER: " << tmp << endl;
                exit(0);
            }
            int chlen = ptr->len / tmp;
            for(int i=0; i<tmp; i++)
            {
                bs_var_type* chptr = new bs_var_type;
                chptr->len = chlen;
                chptr->name = ptr->name + "[" + int_to_str(i) + "]";
                chptr->value = 0;
                ptr->ch.push_back(chptr);
            }
            unsigned long long beta = (1ull << chlen) - 1;
            for(int i=tmp-1; i>=0; i--)
            {
                ptr->ch[i]->value = ptr->value & beta;
                ptr->value = ptr->value >> chlen;
            }
            now++;
        }
        else if(gra[now].type==5)
        {
            bs_var_type* ptr = find_bs_varp(gra[now].var,gra[now].bs_varp);
            int tmp = ptr->ch.size();
            if(tmp<=1 || ptr->len%tmp!=0)
            {
                cerr << "MERGE NODE WITH WRONG CHILDREN NUMBER: " << tmp << endl;
                exit(0);
            }
            int chlen = ptr->len / tmp;
            ptr->value = 0;
            for(int i=0; i<tmp; i++)
            {
                bs_var_type* chptr = ptr->ch[i];
                if(chptr==NULL || chptr->ch.size()!=0 || chptr->len!=chlen)
                {
                    cerr << "MERGE HIGH LEVEL NODE" << endl;
                    exit(0);
                }
                ptr->value = (ptr->value << chlen) | chptr->value;
                delete chptr;
            }
            ptr->ch.clear();
            now++;
        }
        else
        {
            cerr << "GRA TYPE ERROR:" << endl;
            output_gra(now);
            exit(0);
        }
    }
}

void solve_task1()
{
    int k;
    unsigned long long state, key;
    string str1,str2;
    cin >> k;
    for(int i=0; i<k; i++)
    {
        cin >> str1 >> str2;
        if(str1.length()!=bs_var[0].len || str2.length()!=bs_var[1].len || !bs_to_num(str1,state) || !bs_to_num(str2,key))
        {
            cerr << "BS FORMAT WRONG:" << endl;
            cerr << str1 << endl;
            cerr << str2 << endl;
            exit(0);
        }
        num_to_bs(encrypt(state,key),str1,bs_var[0].len);
        cout << str1 << endl;
    }
}

int main()
{
    cin >> task_id;
    if(task_id=="TASKA")
    {
        cin >> n >> m;
        read_ptable();
        read_sbox();
        read_code();
        //cout << code;
        lex_ana();
        //output_lex();
        init_bs_var();
        //output_bs_var();
        gra_ana();
        //output_gra();
        //output_expr();
        solve_task1();
    }
    else if(task_id=="TASKB")
    {

    }
    else{
        cerr << "WRONG TASK ID" << endl;
        exit(0);
    }
    return 0;
}
