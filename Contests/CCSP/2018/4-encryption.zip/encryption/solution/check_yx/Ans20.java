


import java.io.FileInputStream;
import java.io.*;
import java.util.*;

class Stat{

}

class PTable{
    int inSize;
    int outSize;
    List<Integer> data=new ArrayList<>();
}
class SBox{
    int inSize;
    int outSize;
    List<Integer> data=new ArrayList<>();
}
class BinaryVar{
    BinaryVar(String name,int l){
        this.name=name;
        this.len=l;
    }
    int len;
    String name;
    //long value;
    String value;
    List<BinaryVar> splits=null;
}
class LoopVar{
    String name;
}
class BinaryCons implements Expr{
    //int len;
    //long data;
    String data;
}
enum ExprType{
    VAR,
    XOR,
    PTABLE,
    SBOX,
}
//class Expr{
//    ExprType type;
//    String varName;
//    BinaryCons con;
//    List<Object> exprs=new ArrayList<>();
//}
interface Expr{

}
enum IndexExprType{
    CONS,
    LOOP
}
class PTableExpr implements Expr{
    IndexExprType type;
    int index;
    String loopVarName;
    Expr expr;
}
class SBoxExpr implements Expr{
    IndexExprType type;
    int index;
    String loopVarName;
    Expr expr;
}
class XorExpr implements Expr{
    Expr exprLeft;
    Expr exprRight;
}
class AssignStat extends Stat{
    BinaryVarExpr binaryVarExpr;
    Expr expr;
    //List<BaseExpr> baseExprs=new ArrayList<>();
}
class LoopStat extends Stat{
    LoopVar loopVar;
    int s;
    int e;
    List<Stat> stats=new ArrayList<>();
}
enum BinaryVarExprType{
    RAW,
    CONS,
    LOOPVAR
}



class BinaryVarExpr implements Expr{
    BinaryVarExprType type;
    String varName;//raw
    int consIndex;//cons
    String loopVarName;//loop
    BinaryVarExpr subExpr;//cons & loop
}
class SplitStat extends Stat{
    BinaryVarExpr binaryVarExpr;
    int splitCount;
}
class MergeStat extends Stat{
    BinaryVarExpr binaryVarExpr;
}
class EncodeTask{
    String data;
    String key;
}
class Logger{
    public static void log(String s,Object...args){
        //System.out.printf(s,args);
    }
}
class LangCode{
    List<PTable> pTables=new ArrayList<>();
    List<SBox> sBoxes=new ArrayList<>();
    List<BinaryVar> binaryVars=new ArrayList<>();
    List<Stat> stats=new ArrayList<>();
    List<EncodeTask> tasks=new ArrayList<>();
    public void dump(){
        Logger.log("%s\n","start dump");
        Logger.log("%d %d\n",pTables.size(),sBoxes.size());
        for (int i = 0; i < pTables.size(); i++) {
            Logger.log("%d %d\n",pTables.get(i).inSize,pTables.get(i).outSize);
            for (int j = 0; j < pTables.get(i).data.size(); j++) {
                Logger.log("%d ",pTables.get(i).data.get(j));
            }
            Logger.log("\n");
        }
        for (int i = 0; i < sBoxes.size(); i++) {
            Logger.log("%d %d\n",sBoxes.get(i).inSize,sBoxes.get(i).outSize);
            for (int j = 0; j < sBoxes.get(i).data.size(); j++) {
                Logger.log("%d ",sBoxes.get(i).data.get(j));
            }
            Logger.log("\n");
        }
        //
        for (int i = 0; i < binaryVars.size(); i++) {
            Logger.log("%s(%d)\n",binaryVars.get(i).name,binaryVars.get(i).len);
        }
        Logger.log("%d task\n",tasks.size());
        //
        for (int i = 0; i < tasks.size(); i++) {
            Logger.log("%s\n",tasks.get(i).data);
            Logger.log("%s\n",tasks.get(i).key);
        }
        //
        Logger.log("%s\n","stat dump code");

    }
}
class Token{
    String value;
    Token(String c){
        this.value=c;
    }
}
class ParserContext{
    int i;
}

public class Ans20 {
    String code;
    List<Token> tokens=new ArrayList<>();
    HashSet<String> spTokens=new HashSet<>();
    HashSet<Character> spChars=new HashSet<>();
    HashSet<Character> stopChars=new HashSet<>();

    LangCode langCode=new LangCode();
    ParserContext parserContext=new ParserContext();

    static int LEVEL1=1;
    static int LEVEL2=2;
    static int LEVEL3=3;
    static int LEVEL4=4;
    static int LEVEL5=5;

    int subTaskLevel=1;

    Ans20(){
        spTokens.add("BEGIN");
        spTokens.add("END");
        spTokens.add("P");
        spTokens.add("S");
        spTokens.add("LOOP");
        spTokens.add("ENDLOOP");
        spTokens.add("SPLIT");
        spTokens.add("MERGE");
        spChars.add('=');
        spChars.add('(');
        spChars.add(')');
        spChars.add('[');
        spChars.add(']');
        spChars.add('+');
        spChars.add(',');
        spChars.add('"');
        stopChars.add(' ');
        stopChars.add('\t');

    }
    boolean isNumber(char c){
        return c<='9'&&c>='0';
    }
    boolean isLetter(char c){
        return (c<='Z'&&c>='A')||(c<='z'&&c>='a');
    }
    boolean isSpChar(char c){
        return spChars.contains(c);
    }
    boolean isSpToken(String s){
        return spTokens.contains(s);
    }
    boolean isStopChar(char s){
        return stopChars.contains(s);
    }

    void lexical(){
        StringBuilder tmp=new StringBuilder();
        for (int i = 0; i < this.code.length(); i++) {
            char c=code.charAt(i);
            if(isStopChar(c)){
                if(tmp!=null&&tmp.toString().length()!=0){
                    tokens.add(new Token(tmp.toString()));
                    tmp=new StringBuilder();
                }
                continue;
            }else if(isSpChar(c)){
                if(tmp!=null&&tmp.toString().length()!=0){
                    tokens.add(new Token(tmp.toString()));
                    tmp=new StringBuilder();
                }
                tokens.add(new Token(Character.toString(c)));
            }else {
                tmp.append(c);
            }
        }
    }
    void printAllTokens(){
        for (Token token:tokens){
            Logger.log("%s\n",token.value);
        }
    }

    void nextTokenCheck(String c){
        String v=nextString();
        if(!c.equals(v)){
            throw new RuntimeException(String.format("need %s get %s\n",c,v));
        }
    }

    
    Token nextToken(){
        Token t= tokens.get(parserContext.i);
        parserContext.i+=1;
//        if(t.value.equals("000011110000")){
//            Logger.log("\n");
//        }
        Logger.log("next token %s\n",t.value);
        return t;
    }
    int nextInt(){
        Token t=nextToken();
        return Integer.parseInt(t.value);
    }
    String nextString(){
        Token t= nextToken();
        return t.value;
    }
    void parserPTableAndSbox(){
        
        int n=nextInt();
        int m=nextInt();
        for (int i = 0; i < n; i++) {
            PTable pTable=new PTable();
            pTable.inSize=nextInt();
            pTable.outSize=nextInt();
            for (int j = 0; j < pTable.outSize; j++) {
                pTable.data.add(nextInt());
            }
            langCode.pTables.add(pTable);
        }
        for (int i = 0; i < m; i++) {
            SBox sBox=new SBox();
            sBox.inSize=nextInt();
            sBox.outSize=nextInt();
            for (int j = 0; j < (int)Math.pow(2,sBox.inSize); j++) {
                sBox.data.add(nextInt());
            }
            langCode.sBoxes.add(sBox);
        }
    }
    void tokenBack(){
        parserContext.i-=1;
    }
    void parserVar(){
        while (true){
            String name=nextString();
            if(spTokens.contains(name)){
                tokenBack();
                return;
            }else {
                nextToken();
                int len=nextInt();
                nextToken();
                BinaryVar binaryVar=new BinaryVar(name,len);
                langCode.binaryVars.add(binaryVar);
            }
        }

    }
    Stat parserStat(){
        String s=nextString();
        Stat stat;
        tokenBack();
        if(s.equals("LOOP")){
            stat=parserLoop();
        }else if(s.equals("SPLIT")){
            stat=parserSplit();
        }else if(s.equals("MERGE")){
            stat=parserMerge();
        }else {
            stat=parserAssign();
        }
        return stat;
    }
    Stat parserLoop(){
        String s=nextString();
        LoopStat loopStat=new LoopStat();
        if(!s.equals("LOOP")){
            throw new RuntimeException();
        }
        loopStat.loopVar=new LoopVar();
        loopStat.loopVar.name=nextString();
        loopStat.s=nextInt();
        loopStat.e=nextInt();
        while (true){
            String s1=nextString();
            if(s1.equals("ENDLOOP")){
                break;
            }
            tokenBack();
            Stat stat=parserStat();
            loopStat.stats.add(stat);
        }
        return loopStat;
    }
    Stat parserSplit(){
        String s=nextString();
        if(!s.equals("SPLIT")){
            throw new RuntimeException();
        }
        nextTokenCheck("(");
        SplitStat splitStat=new SplitStat();
        splitStat.binaryVarExpr=parserBinaryVarExpr();
        nextTokenCheck(",");
        splitStat.splitCount=nextInt();
        nextTokenCheck(")");
        return splitStat;
    }
    Stat parserMerge(){
        String s=nextString();
        if(!s.equals("MERGE")){
            throw new RuntimeException();
        }
        nextTokenCheck("(");
        MergeStat mergeStat=new MergeStat();
        mergeStat.binaryVarExpr=parserBinaryVarExpr();
        nextTokenCheck(")");
        return mergeStat;
    }
    boolean isInteger(String s){
        return s.matches("\\d+");
    }
    BinaryVarExpr parserBinaryVarExpr(){
        BinaryVarExpr tail=new BinaryVarExpr();
        String name=nextString();
        tail.varName=name;
        tail.type=BinaryVarExprType.RAW;
        while (true){
            String s=nextString();
            if(s.equals("[")){
                String index=nextString();
                BinaryVarExpr newTail=new BinaryVarExpr();
                newTail.subExpr=tail;
                tail=newTail;
                if(isInteger(index)){
                    tail.type=BinaryVarExprType.CONS;
                    tail.consIndex=Integer.parseInt(index);
                }else {
                    tail.type=BinaryVarExprType.LOOPVAR;
                    tail.loopVarName=index;
                }
                nextTokenCheck("]");
            }else {
                tokenBack();
                break;
            }
        }
        return tail;
    }
    Expr tryParserXor(Expr left){
        String s=nextString();
        if(s.equals("+")){
            Expr right=parserExpr();
            XorExpr xorExpr=new XorExpr();
            xorExpr.exprLeft=left;
            xorExpr.exprRight=right;
            return xorExpr;
        }else {
            tokenBack();
            return left;
        }
    }

    Expr parserExpr(){
        String s=nextString();
        tokenBack();
        if(s.equals("S")){
            nextToken();
            nextTokenCheck("[");
            SBoxExpr sBoxExpr=new SBoxExpr();
            String value=nextString();
            if(isInteger(value)){
                sBoxExpr.type=IndexExprType.CONS;
                sBoxExpr.index=Integer.parseInt(value);
            }else {
                sBoxExpr.type=IndexExprType.LOOP;
                sBoxExpr.loopVarName=value;
            }
            nextTokenCheck("]");
            nextTokenCheck("(");
            sBoxExpr.expr=parserExpr();
            nextTokenCheck(")");
            return tryParserXor(sBoxExpr);
        }else if(s.equals("P")){
            nextToken();
            PTableExpr pTableExpr=new PTableExpr();
            nextTokenCheck("[");
            String value=nextString();
            if(isInteger(value)){
                pTableExpr.type=IndexExprType.CONS;
                pTableExpr.index=Integer.parseInt(value);
            }else {
                pTableExpr.type=IndexExprType.LOOP;
                pTableExpr.loopVarName=value;
            }
            nextTokenCheck("]");
            nextTokenCheck("(");
            pTableExpr.expr=parserExpr();
            nextTokenCheck(")");
            return tryParserXor(pTableExpr);
        }else if(s.equals("\"")){
            nextTokenCheck("\"");
            BinaryCons binaryCons=new BinaryCons();
            String value=nextString();
            //binaryCons.len=value.length();
            binaryCons.data=value;
            nextTokenCheck("\"");
            return tryParserXor(binaryCons);
        }else {
            BinaryVarExpr binaryVarExpr =parserBinaryVarExpr();
            return tryParserXor(binaryVarExpr);
        }
    }

    Stat parserAssign(){
        AssignStat assignStat=new AssignStat();
        BinaryVarExpr binaryVarExpr=parserBinaryVarExpr();
        assignStat.binaryVarExpr=binaryVarExpr;
        nextTokenCheck("=");
        Expr expr=parserExpr();
        assignStat.expr=expr;
        return assignStat;
    }
    void parserCode(){
        nextTokenCheck("BEGIN");
        while (true){
            String s=nextString();
            if(s.equals("END")){
                return;
            }
            tokenBack();
            //parser
            Stat stat=parserStat();
            langCode.stats.add(stat);
        }
    }
    void parserData(){
        int n=nextInt();
        for (int i = 0; i < n; i++) {
            EncodeTask task=new EncodeTask();
            task.data=nextString();
            task.key=nextString();
            langCode.tasks.add(task);
        }
    }
    void parser(){
        parserContext.i=0;
        parserPTableAndSbox();
        parserVar();
        parserCode();
        parserData();
        langCode.dump();
        Logger.log("done\n");
    }
    class EvalContent{
        HashMap<String,BinaryVar> binaryVars=new HashMap<>();
        HashMap<String,Integer> loopVars=new HashMap<>();
    }

    BinaryVar evalBinaryVarExpr(BinaryVarExpr binaryVarExpr,EvalContent evalContent){
        if(binaryVarExpr.type==BinaryVarExprType.RAW){
            return evalContent.binaryVars.get(binaryVarExpr.varName);
        }else {
            int index;
            if(binaryVarExpr.type==BinaryVarExprType.CONS){
                index=binaryVarExpr.consIndex;
            }else {
                index=evalContent.loopVars.get(binaryVarExpr.loopVarName);
            }
            BinaryVar subVar=evalBinaryVarExpr(binaryVarExpr.subExpr,evalContent);
            if(index>=subVar.splits.size()){
                Logger.log("");
            }
            return subVar.splits.get(index);
        }
    }

    String intToString(int v,int len){
        String s=Integer.toString(v,2);
        StringBuilder sb=new StringBuilder();
        for (int i = 0; i < len-s.length(); i++) {
            sb.append("0");
        }
        sb.append(s);
        return sb.toString();
    }

    BinaryCons evalExpr(Expr expr,EvalContent evalContent){
        BinaryCons res=new BinaryCons();
        if(expr instanceof PTableExpr){
            PTableExpr pTableExpr=(PTableExpr)expr;
            BinaryCons v1=evalExpr(pTableExpr.expr,evalContent);
            //
            PTable pTable=null;
            if(pTableExpr.type==IndexExprType.CONS){
                pTable=langCode.pTables.get(pTableExpr.index);
            }else {
                pTable=langCode.pTables.get(evalContent.loopVars.get(pTableExpr.loopVarName));
            }
            StringBuilder sb=new StringBuilder();
            for (Integer i:pTable.data) {
                if(v1.data.length()<=i){
                    Logger.log("");
                }
                sb.append(v1.data.charAt(i));
            }
            res.data=sb.toString();
        }else if(expr instanceof SBoxExpr){
            SBoxExpr pTableExpr=(SBoxExpr)expr;
            BinaryCons v1=evalExpr(pTableExpr.expr,evalContent);
            //
            SBox sBox=null;
            if(pTableExpr.type==IndexExprType.CONS){
                sBox=langCode.sBoxes.get(pTableExpr.index);
            }else {
                sBox=langCode.sBoxes.get(evalContent.loopVars.get(pTableExpr.loopVarName));
            }
            Integer lv1=Integer.parseInt(v1.data,2);
            Integer rv = sBox.data.get(lv1);
            res.data=intToString(rv,sBox.outSize);
        }else if(expr instanceof BinaryCons){
            return (BinaryCons)expr;
        }else if(expr instanceof BinaryVarExpr){
            BinaryVarExpr binaryVarExpr=(BinaryVarExpr)expr;
            BinaryVar var=evalBinaryVarExpr(binaryVarExpr,evalContent);
            res.data=var.value;
        }else if(expr instanceof XorExpr){
            XorExpr xorExpr=(XorExpr)expr;
            BinaryCons cons1= evalExpr(xorExpr.exprLeft,evalContent);
            BinaryCons cons2= evalExpr(xorExpr.exprRight,evalContent);
            res=strXor(cons1,cons2);
        }
        return res;
    }
    BinaryCons strXor(BinaryCons v1,BinaryCons v2){
        StringBuilder sb=new StringBuilder();
        for (int i = 0; i < v1.data.length(); i++) {
            if(v1.data.charAt(i)!=v2.data.charAt(i)){
                sb.append('1');
            }else {
                sb.append('0');
            }
        }
        BinaryCons res= new BinaryCons();
        res.data=sb.toString();
        return res;
    }

    void checkSplit(BinaryVar var){
        if(var.value==null){
            throw new RuntimeException();
        }else if(var.splits!=null){
            throw new RuntimeException();
        }
    }
    void checkMerge(BinaryVar var){
        if(var.value!=null){
            throw new RuntimeException();
        }else if(var.splits==null){
            throw new RuntimeException();
        }
    }
    List<String> strPartition(String s,int size){
        List<String> res=new ArrayList<>();
        for (int i = 0; i < s.length(); i+=size) {
            res.add(s.substring(i,i+size));
        }
        return res;
    }
    void evalStat(Stat stat,EvalContent evalContent){
        if(stat instanceof AssignStat){
            AssignStat assignStat=(AssignStat)stat;
            BinaryVar var=evalBinaryVarExpr(assignStat.binaryVarExpr,evalContent);
            BinaryCons cons=evalExpr(assignStat.expr,evalContent);
            var.value=cons.data;
        }else if(stat instanceof SplitStat){
            if(subTaskLevel==LEVEL2||subTaskLevel==LEVEL1){
                return;
            }
            SplitStat splitStat=(SplitStat)stat;
            BinaryVar var=evalBinaryVarExpr(splitStat.binaryVarExpr,evalContent);
            checkSplit(var);
            int newLen=var.value.length()/splitStat.splitCount;
            List<String> strings= strPartition(var.value,var.value.length()/splitStat.splitCount);
            var.splits=new ArrayList<>();
            for (String s:strings){
                BinaryVar newVar=new BinaryVar(null,newLen);
                newVar.value=s;
                var.splits.add(newVar);
            }
            var.value=null;
        }else if(stat instanceof MergeStat){
            if(subTaskLevel==LEVEL2||subTaskLevel==LEVEL1){
                return;
            }
            MergeStat mergeStat=(MergeStat)stat;
            BinaryVar var=evalBinaryVarExpr(mergeStat.binaryVarExpr,evalContent);
            checkMerge(var);
            StringBuilder sb=new StringBuilder();
            for (int i = 0; i < var.splits.size(); i++) {
                sb.append(var.splits.get(i).value);
            }
            var.splits=null;
            var.value=sb.toString();
        }else if(stat instanceof LoopStat){
            if(subTaskLevel==LEVEL3||subTaskLevel==LEVEL1){
                return;
            }
            LoopStat loopStat=(LoopStat)stat;
            for (int i = loopStat.s; i <=loopStat.e; i++) {
                evalContent.loopVars.put(loopStat.loopVar.name,i);
                for (Stat ls: loopStat.stats){
                    evalStat(ls,evalContent);
                }
            }
            evalContent.loopVars.remove(loopStat.loopVar.name);
        }else {
            throw new RuntimeException();
        }
    }
    String initString(int len){
        StringBuilder sb=new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append('0');
        }
        return sb.toString();
    }
    String encrypt(String state,String key){
        EvalContent content=new EvalContent();
        BinaryVar stateVar=new BinaryVar("state",state.length());
        stateVar.value=state;
        content.binaryVars.put("state",stateVar);
        BinaryVar keyVar=new BinaryVar("key",key.length());
        keyVar.value=key;
        content.binaryVars.put("key",keyVar);
        //add other var
        for (BinaryVar var:langCode.binaryVars){
            BinaryVar newBar=new BinaryVar(var.name,var.len);
            newBar.value=initString(var.len);
            if(!content.binaryVars.containsKey(newBar.name)){
                content.binaryVars.put(newBar.name,newBar);
            }
        }
        //run
        for (int j = 0; j < langCode.stats.size(); j++) {
            evalStat(langCode.stats.get(j),content);
        }
        return content.binaryVars.get("state").value;
    }

    void eval(){
        for (int i = 0; i < langCode.tasks.size(); i++) {
            String state=langCode.tasks.get(i).data;
            String key=langCode.tasks.get(i).key;
            String ans=encrypt(state,key);
            //output
            System.out.printf("%s\n",ans);
            if(subTaskLevel<=LEVEL3){
                break;
            }
        }
    }

    void readAllCode(Scanner scanner){
        StringBuilder sb=new StringBuilder();
        while (scanner.hasNextLine()){
            String l=scanner.nextLine();
            sb.append(" ");
            sb.append(l);
        }
        sb.append(" ");
        this.code=sb.toString();
        Logger.log("\n",code);
    }

    static String task2code="";
    static {
        String code="";
        code+="3 1\n";
        code+="16 16\n";
        code+="12  1  9  2  0  11  7  3 4  15  8  5  14  13  10  6\n";
        code+="16 16\n";
        code+="1  2  3  4  5  6  7  8  9 10  11  12  13  14  15  0\n";
        code+="16 16\n";
        code+="0  1  2  3  4  5  6  7  8  9 10  11  12  13  14  15\n";
        code+="4 4\n";
        code+="12  5  6  11  9  0  10  13 3  14  15  8  4  7  1  2\n";

        code += "state(32)\n";
        code += "key(12)\n";
        code += "dkey(16)\n";
        code += "tmp(32)\n";
        code += "BEGIN\n";
        code += "SPLIT(dkey,4)\n";
        code += "SPLIT(key,3)\n";
        code += "dkey[0] = key[0]\n";
        code += "dkey[1] = key[1]\n";
        code += "dkey[2] = key[2]\n";
        code += "dkey[3] = key[0] + key[1] + key[2]\n";
        code += "MERGE(key)\n";
        code += "MERGE(dkey)\n";
        code += "LOOP i 1 16\n";
        //利用des特点，修改key的使用次序就可以解密
        code += "dkey = P[2](dkey)\n";
        code += "tmp = state\n";
        code += "SPLIT(state,2)\n";
        code += "SPLIT(tmp,2)\n";
        code += "state[0] = tmp[1]\n";
        code += "tmp[1] = tmp[1] + dkey\n";
        code += "SPLIT(tmp[1],4)\n";
        code += "LOOP j 0 3\n";
        code += "tmp[1][j] = S[0](tmp[1][j])\n";
        code += "ENDLOOP\n";
        code += "MERGE(tmp[1])\n";
        code += "state[1] = tmp[0] + P[0](tmp[1])\n";
        code += "MERGE(state)\n";
        code += "MERGE(tmp)\n";
        code += "dkey = P[1](dkey)\n";
        code += "ENDLOOP\n";
        code += "tmp = state\n";
        code += "SPLIT(state,2)\n";
        code += "SPLIT(tmp,2)\n";
        code += "state[0] = tmp[1]\n";
        code += "state[1] = tmp[0]\n";
        code += "MERGE(state)\n";
        code += "MERGE(tmp)\n";
        code += "END\n";
        code += "0\n";
        task2code=code;
    }

    void runTaskb(String state,String ans){
        int keySize=12;
        HashMap<String,String> ans1Tokey=new HashMap<>();
        for (int i = 0; i < Math.pow(2,keySize); i++) {
            String key=intToString(i,keySize);
            String ans1=encrypt(state,key);
            ans1Tokey.put(ans1,key);
        }
        //反向解密
        int[] p1=new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        int[] p2=new int[]{15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
        langCode.pTables.get(1).data.clear();
        for (int v:p1){
            langCode.pTables.get(1).data.add(v);
        }
        langCode.pTables.get(2).data.clear();
        for (int v:p2){
            langCode.pTables.get(2).data.add(v);
        }
        //
        for (int i = 0; i < Math.pow(2,keySize); i++) {
            String key=intToString(i,keySize);
            String ans2=encrypt(ans,key);
            if(ans1Tokey.containsKey(ans2)){
                System.out.printf("YES\n%s\n%s\n",ans1Tokey.get(ans2),key);
                return;
            }
        }
        System.out.printf("NO\n");
        Logger.log("");
    }

    public void run(InputStream inputStream){
        Scanner scanner=new Scanner(inputStream);
        String line1=scanner.nextLine();
        boolean taska=line1.startsWith("TASKA");
        if(taska){
            readAllCode(scanner);
            lexical();
            printAllTokens();
            parser();
            eval();
        }else {
            if(subTaskLevel>=LEVEL5){
                Scanner codeScanner=new Scanner(task2code);
                readAllCode(codeScanner);
                lexical();
                printAllTokens();
                parser();
                String state=scanner.nextLine();
                String ans=scanner.nextLine();
                runTaskb(state,ans);
            }
        }
    }

    public static void main(String args[]) throws Exception {
        InputStream inputStream=System.in;
        //inputStream=new FileInputStream(new File("data_3/9.in"));
        Ans20 game=new Ans20();
        game.run(inputStream);
        //game.dump();
    }
}
