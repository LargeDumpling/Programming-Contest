import java.util.Random;

public class Tester {

    public void test(int W, int H, int N) {

        System.err.printf("Begin to test, W = %d, H = %d, N = %d \n", W, H, N);

        float input[] = new float[(W + N - 1) * (H + N - 1)];
        float output_base[] = new float[W * H];
        float output[] = new float[W * H];

        genInput(input);

        long startTime = System.nanoTime();
        solveNaive(W, H, N, input, output_base);
        long endTime = System.nanoTime();

        System.err.printf("Time consumed by naive method: %.2f ms\n", (endTime - startTime) * 1e-6);

        startTime = System.nanoTime();
        Solver.solve(W, H, N, input, output);
        endTime = System.nanoTime();

        if (checkResult(output_base, output))
            System.err.print("Your result is correct.\n");
        else
            System.err.print("Your result is wrong.\n");

        System.err.printf("Time consumed by your method: %.2f ms\n", (endTime - startTime) * 1e-6);

    }

    private void genInput(float input[]) {

        Random random = new Random(0);

        for (int i = 0; i < input.length; i++)
            input[i] = random.nextFloat();
    }

    private boolean checkResult(float x[], float y[]) {

        if (x.length != y.length)
            return false;

        final float eps = 1e-5f;

        int n = x.length;

        for (int i = 0; i < n; i++) {
            if (Math.abs(x[i] - y[i]) > eps)
                return false;
        }

        return true;
    }

    private void solveNaive(int W, int H, int N, float[] input, float[] output) {
        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                float tmp = 0;
                for (int ii = 0; ii < N; ii++)
                    for (int jj = 0; jj < N; jj++)
                        tmp += input[(i + ii) * (W + N - 1) + j + jj];

                tmp = tmp / (N * N);
                output[i * W + j] = tmp;
            }
        }
    }
}