#include "simd.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

void solve(int W, int H, int N, float *input, float *output) {
    const int CHUNK_SIZE = 64;

#pragma omp parallel for
    for (int i = 0; i < H; i += CHUNK_SIZE) {

        float *tmp_buf =
            (float *)malloc(sizeof(float) * W * (CHUNK_SIZE + N - 1));

        for (int ii = 0; ii < CHUNK_SIZE + N - 1 && i + ii < H + N - 1; ii++)
            for (int j = 0; j < W; j++) {
                float tmp = 0;
                for (int jj = 0; jj < N; jj++)
                    tmp += input[(i + ii) * (W + N - 1) + j + jj];

                tmp_buf[ii * W + j] = tmp / N;
            }

        for (int ii = 0; ii < CHUNK_SIZE && i + ii < H; ii++)
            for (int j = 0; j < W; j++) {
                float tmp = 0;
                for (int jj = 0; jj < N; jj++)
                    tmp += tmp_buf[(jj + ii) * W + j];

                output[(i + ii) * W + j] = tmp / N;
            }

        free(tmp_buf);
    }
}
