public class Solver {

    public static void solve(int W, int H, int N, float[] input, float[] output) {

        class MyRunnable implements Runnable {

            int start;
            int end;

            public MyRunnable(int s, int e) {
                this.start = s;
                this.end = e;
            }

            public void run() {
                for (int i = this.start; i < this.end; i++) {
                    for (int j = 0; j < W; j++) {
                        float tmp = 0;
                        for (int ii = 0; ii < N; ii++) {
                            for (int jj = 0; jj < N; jj++) {
                                tmp += input[(i + ii) * (W + N - 1) + j + jj];
                            }
                        }
                        tmp = tmp / (N * N);
                        output[i * W + j] = tmp;
                    }
                }

            }
        }
        int step = H / 4;
        Thread t1 = new Thread(new MyRunnable(0, step));
        Thread t2 = new Thread(new MyRunnable(step, 2 * step));
        Thread t3 = new Thread(new MyRunnable(2 * step, 3 * step));
        Thread t4 = new Thread(new MyRunnable(3 * step, H));
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();

        } catch (Exception e) {

        }
    }
}
