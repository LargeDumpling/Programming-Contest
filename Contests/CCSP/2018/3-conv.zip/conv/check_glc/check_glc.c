#include "simd.h"
#include <stdio.h>
#include <stdlib.h>

void solve(int W, int H, int N, float *input, float *output){
    int width = W + N - 1;
#pragma omp parallel for
    for (int i = 0; i < H; ++i){
        float *buf = malloc(sizeof(float) * W * N);
        //先计算行方向上均值
        for (int ii = 0; ii < N; ++ii){
            for (int j = 0; j < W; ++j){
                float tmp = 0.0f;
                for (int jj = 0; jj < N; ++jj){
                    tmp += input[(i + ii) * width + (j + jj)];
                }
                buf[ii * W + j] = tmp / N;
            }
        }
        //再计算列方向上均值
        for (int j = 0; j < W; ++j){
            float tmp = 0.0f;
            for (int jj = 0; jj < N; ++jj){
                tmp += buf[jj * W + j];
            }
            output[i * W + j] = tmp / N;
        }
        free(buf);
    }
}