#ifndef SOLVE_H_
#define SOLVE_H_

// The address of input and output are aligned to 4KB.
void solve(int W, int H, int N, float *input, float *output);

#endif
