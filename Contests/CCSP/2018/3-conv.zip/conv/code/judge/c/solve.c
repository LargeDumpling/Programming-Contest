#include "simd.h"
#include "solve.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>


void solve(int W, int H, int N, float *input, float *output) {
}
