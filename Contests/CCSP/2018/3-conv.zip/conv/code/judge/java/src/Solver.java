class Solver {
    public static void solve(int W, int H, int N, float[] input, float[] output) {
        
    }
}