import java.util.Random;

public class Tester {

    public void test(int W, int H, int N) {

        float input[] = new float[(W + N - 1) * (H + N - 1)];
        float output_base[] = new float[W * H];
        float output[] = new float[W * H];

        genInput(input);

        solveNaiveE693(W, H, N, input, output_base);

        float startTime = System.nanoTime();
        Solver.solve(W, H, N, input, output);
        float endTime = System.nanoTime();

        int correctness = checkResult(output_base, output) ? 1 : 0;

        String flag = "e693628d405583b465b9d35e5e164d8d78276ef52f659b955d083e565e2522e6";
        System.out.printf("%s %d %f\n", flag, correctness, (endTime - startTime) * 1e-6);

    }

    private void genInput(float input[]) {

        Random random = new Random(132856);

        for (int i = 0; i < input.length; i++)
            input[i] = random.nextFloat();
    }

    private boolean checkResult(float x[], float y[]) {

        if (x.length != y.length)
            return false;

        final float eps = 1e-5f;

        int n = x.length;

        for (int i = 0; i < n; i++) {
            if (Math.abs(x[i] - y[i]) > eps)
                return false;
        }

        return true;
    }

    private void solveNaiveE693(int W, int H, int N, float[] input, float[] output) {

        class MyRunnable implements Runnable {

            int start;
            int end;

            public MyRunnable(int s, int e) {
                this.start = s;
                this.end = e;
            }

            public void run() {

                final int CHUNK_SIZE = 64;
                for (int i = start; i < end; i += CHUNK_SIZE) {
                    float tmp_buf[] = new float[W * N * (CHUNK_SIZE + N - 1)];

                    for (int ii = 0; ii < CHUNK_SIZE + N - 1 && i + ii < H + N - 1; ii++)
                        for (int j = 0; j < W; j++) {
                            float tmp = 0;
                            for (int jj = 0; jj < N; jj++)
                                tmp += input[(i + ii) * (W + N - 1) + j + jj];

                            tmp_buf[ii * W + j] = tmp / N;
                        }

                    for (int ii = 0; ii < CHUNK_SIZE && i + ii < H; ii++)
                        for (int j = 0; j < W; j++) {
                            float tmp = 0;
                            for (int jj = 0; jj < N; jj++)
                                tmp += tmp_buf[(jj + ii) * W + j];

                            output[(i + ii) * W + j] = tmp / N;
                        }

                }

            }
        }

        int cores = Runtime.getRuntime().availableProcessors();
        Thread threads[] = new Thread[cores];
        for (int i = 0; i < cores; i++) {
            threads[i] = new Thread(new MyRunnable(H / cores * i, H / cores * (i + 1)));
            threads[i].start();
        }

        try {
            for (int i = 0; i < cores; i++)
                threads[i].join();
        } catch (Exception e) {

        }
    }

}
