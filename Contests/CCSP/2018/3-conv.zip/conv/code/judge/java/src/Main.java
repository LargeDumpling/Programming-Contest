import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Tester tester = new Tester();
        int W, H, N;
        Scanner scan = new Scanner(System.in);
        W = scan.nextInt();
        H = scan.nextInt();
        N = scan.nextInt();
        tester.test(W,H,N);
    }

}