#include "simd.h"
#include <stdio.h>
#include <stdlib.h>

void solve(int W, int H, int N, float *input, float *output) {}
