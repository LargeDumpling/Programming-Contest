
#include "simd.h"
#include "solve.h"
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>

const char *flag =
    "e693628d405583b465b9d35e5e164d8d78276ef52f659b955d083e565e2522e6";

void solve_naive_e693(int W, int H, int N, float *input, float *output) {
    const int Y_TILE_SIZE = 32;
    const int X_TILE_SIZE = 256;

    vec_t divisor = vec_set1_float(1.0 / N);
#pragma omp parallel for
    for (int yTile = 0; yTile < H; yTile += Y_TILE_SIZE) {

        vec_t tmp[X_TILE_SIZE / VEC_SIZE * (Y_TILE_SIZE + N - 1)];
        vec_t sum, avg;
        vec_t *tmp_ptr;

        for (int xTile = 0; xTile < W; xTile += X_TILE_SIZE) {

            for (int y = 0; y < Y_TILE_SIZE + N - 1 && yTile + y < H + N - 1;
                 y++) {

                float *in_ptr = input + (yTile + y) * (W + N - 1) + xTile;
                tmp_ptr = tmp + y * X_TILE_SIZE / VEC_SIZE;

                for (int x = 0; x < X_TILE_SIZE && xTile + x < W;
                     x += VEC_SIZE) {
                    sum = vec_set1_float(0.0);
                    for (int i = 0; i < N; i++)
                        sum = vec_add(sum, vec_load(in_ptr + i));
                    avg = vec_mul(sum, divisor);
                    vec_store((float *)tmp_ptr, avg);
                    tmp_ptr++;
                    in_ptr += VEC_SIZE;
                }
            }

            tmp_ptr = tmp;

            for (int y = 0; y < Y_TILE_SIZE && y + yTile < H; y++) {
                vec_t *out_ptr = (vec_t *)(output + (yTile + y) * W + xTile);

                tmp_ptr = tmp + y * X_TILE_SIZE / VEC_SIZE;

                for (int x = 0; x < X_TILE_SIZE && xTile + x < W;
                     x += VEC_SIZE) {
                    sum = vec_set1_float(0.0);
                    for (int i = 0; i < N; i++)
                        sum = vec_add(sum,
                                      *(tmp_ptr + i * X_TILE_SIZE / VEC_SIZE));

                    avg = vec_mul(sum, divisor);
                    vec_store((float *)out_ptr, avg);
                    tmp_ptr++;
                    out_ptr++;
                }
            }
        }
    }
}

int seed = 132856;
#define FAST_RAND_MAX 32767

inline int fast_rand() {
    seed = 214013 * seed + 2531011;
    return (seed >> 16) & 0x7FFF;
}

void gen_input(int W, int H, int N, float *input) {
    for (int i = 0; i < (W + N - 1) * (H + N - 1); i++)
        input[i] = fast_rand() / (float)FAST_RAND_MAX;
}

int check_result(float *x, float *y, int n) {
    const float eps = 1e-5;

    for (int i = 0; i < n; i++) {
        if (fabsf(x[i] - y[i]) > eps)
            return 0;
    }

    return 1;
}

void test(int W, int H, int N) {

    float *input = (float *)valloc(sizeof(float) * (W + N - 1) * (H + N - 1));
    float *output = (float *)valloc(sizeof(float) * W * H);

    gen_input(W, H, N, input);

    struct timeval begin, end, result;


    gettimeofday(&begin, NULL);
    solve(W, H, N, input, output);
    gettimeofday(&end, NULL);

    float *output_baseline = (float *)valloc(sizeof(float) * W * H);
    solve_naive_e693(W, H, N, input, output_baseline);

    int correctness = check_result(output_baseline, output, W * H);

    float time = (end.tv_sec - begin.tv_sec) * 1000.0 +
                 (end.tv_usec - begin.tv_usec) / 1000.0;
    fprintf(stdout, "%s %d %f\n", flag, correctness, time);

    free(input);
    free(output);
    free(output_baseline);
}

int main(int argc, char **argv) {

    int W, H, N;
    fscanf(stdin, "%d %d %d", &W, &H, &N);
    test(W, H, N);

    return 0;
}
