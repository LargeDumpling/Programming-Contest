public class MyMain {
    public static void main(String[] args) {

        Tester tester=new Tester();

        tester.run(args);

    }
}
