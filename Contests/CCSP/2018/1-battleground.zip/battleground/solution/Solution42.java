
import java.util.ArrayList;
import java.util.Scanner;
class Person8{
    int x1;
    int y1;
    int h;   
    public Person8(int x1,int y1,int h){
    	this.x1=x1;
    	this.y1=y1;
    	this.h=h;
    }
    public Person8(){
    	super();
    }
}

public class Solution42 {
	private static void addPerson(ArrayList<Person8> temp,int xold,int yold,int xnew,int ynew,int[][] obstacles,int h,int n,boolean[][] flag){
		if(xnew<0||xnew>=n||ynew<0||ynew>=n){
			return;
		}
		if(flag[xnew][ynew]){
			return;
		}
		if(obstacles[xnew][ynew]==2){
			return;
		}
		if(obstacles[xold][ynew]==1 && obstacles[xnew][yold]==2){
			return;
		}
		flag[xnew][ynew]=true;
		temp.add(new Person8(xnew,ynew,h-1));
	}
	private static Person8 bfs(Person8 person,int safeAreaX,int safeAreaY,int radius,int[][] obstacles,int n,boolean[][] flag){
		ArrayList<Person8> toCheck = new ArrayList<Person8>();
		toCheck.add(person);
		int aa=0;
		flag[person.x1][person.y1]=true;
		while(!toCheck.isEmpty()){
			ArrayList<Person8> temp = new ArrayList<Person8>();
			for(Person8 p:toCheck){
				int x1=p.x1;
				int y1=p.y1;
				int h=p.h;
				if((x1-safeAreaX)*(x1-safeAreaX)+(y1-safeAreaY)*(y1-safeAreaY) > radius*radius){
					addPerson(temp,x1,y1,x1-1,y1+1,obstacles,h,n,flag);
					addPerson(temp,x1,y1,x1,y1+1,obstacles,h,n,flag);
					addPerson(temp,x1,y1,x1+1,y1+1,obstacles,h,n,flag);
					addPerson(temp,x1,y1,x1+1,y1,obstacles,h,n,flag);
					addPerson(temp,x1,y1,x1+1,y1-1,obstacles,h,n,flag);
					addPerson(temp,x1,y1,x1,y1-1,obstacles,h,n,flag);
					addPerson(temp,x1,y1,x1-1,y1-1,obstacles,h,n,flag);
					addPerson(temp,x1,y1,x1-1,y1,obstacles,h,n,flag);
				}else{
					return p;
				}	
				toCheck = temp;
			}//for end
		}
		return person;
	}
	public static void main(String args[]){
        Scanner sin = new Scanner(System.in);
        int n = sin.nextInt(); 
        int m = sin.nextInt(); 
        int e = sin.nextInt();
        int k = sin.nextInt();
        int h = sin.nextInt();
        Person8[] persons = new Person8[m]; 
        int[][] obstacles=new int[n][n];

        for(int i=0;i<e;i++){
            int x1=sin.nextInt();
        	int y1=sin.nextInt();
        	obstacles[x1][y1]=1;
        }
        for(int i=0;i<m;i++){
            persons[i] = new Person8();
            persons[i].h = h;   
            persons[i].x1 = sin.nextInt();
            persons[i].y1 = sin.nextInt();
        }
        int[] res=new int[m];
        for(int i=0;i<k;i++){
        	int safeAreaX=sin.nextInt();
        	int safeAreaY=sin.nextInt();
        	int radius=sin.nextInt();
        	for(int ii=0;ii<m;ii++){     
        		boolean[][] flag=new boolean[n][n];
        		int x1 = sin.nextInt();
                int y1 = sin.nextInt();
                persons[ii]=bfs(persons[ii],safeAreaX,safeAreaY,radius,obstacles,n,flag);
                int ans = 0;
                if(persons[ii].h>0) ans=persons[ii].h;
                res[ii]=ans;
                persons[ii].x1 = x1;
                persons[ii].y1 = y1;
        	}
        }
    	for(int ans:res){
    		System.out.println(ans);
    	}
	}
}
