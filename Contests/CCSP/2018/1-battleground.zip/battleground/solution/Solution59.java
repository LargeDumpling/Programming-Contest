


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

class Point{
    int x;
    int y;
    Point(){

    }
    Point(int a,int b){
        x=a;
        y=b;
    }
    @Override
    public boolean equals(Object anObject){

        if(anObject==null){
            return false;
        }
        if(!(anObject instanceof Point)){
            return false;
        }
        return x==((Point) anObject).x&&y==((Point) anObject).y;
    }
    @Override
    public int hashCode(){
        return x^y;
    }
}

class Round{
    Point safeCenter=new Point();
    int safeRange;
    List<Point> targets=new ArrayList<Point>();
}
class Player{
    int hp;
    Point pos=new Point();
}

class FooTimer{
    Long t1=null;
    void push(){
        long t2= System.currentTimeMillis();
        if(t1==null){
            t1=t2;
        }
        //System.out.printf("time %d\n",t2-t1);
        t1=t2;
    }
}
class Game{
    FooTimer fooTimer=new FooTimer();
    int mapSize;
    int playerCount;
    int blockerCount;
    int roundCount;
    int initHp;
    List<Player> players=new ArrayList<Player>();
    //HashSet<Point> blockers=new HashSet<Point>();
    List<Round> rounds=new ArrayList<Round>();
    int curRoundIndex =0;

    static List<Point> directions;
    static Round superBigRound;
    static {
        directions=new ArrayList<Point>();
        directions.add(new Point(0,1));
        directions.add(new Point(1,1));
        directions.add(new Point(1,0));
        directions.add(new Point(1,-1));
        directions.add(new Point(0,-1));
        directions.add(new Point(-1,-1));
        directions.add(new Point(-1,0));
        directions.add(new Point(-1,1));
        //
        superBigRound=new Round();
        superBigRound.safeRange=Integer.MAX_VALUE;
        superBigRound.safeCenter=new Point(0,0);
    }
    //

    //
    void init(){
        this.closeSet2=new int[this.mapSize*this.mapSize];
        this.mapInfo=new int[this.mapSize*this.mapSize];
        this.distance2=new int[this.mapSize*this.mapSize];
        this.clearDistance();
    }
    boolean isSafe(Point p,Round r){
        int a=(p.x-r.safeCenter.x);
        int b=(p.y-r.safeCenter.y);
        long v=a*a+b*b;
        return v<=r.safeRange*r.safeRange;
    }
    void clearMapBlockers(){
        for (int i = 0; i < mapInfo.length; i++) {
            mapInfo[i]=0;
        }
    }
    boolean isBlocker(Point p){
        if(!isInMap(p)){
            return true;
        }
        return false;
        //return blockers.contains(p);
    }
    boolean isDiagonal(Point dir){
        return (Math.abs(dir.x)+Math.abs(dir.y))==2;
    }
    boolean inRange(int v,int min,int max){
        return v>=min&&v<=max;
    }
    boolean isInMap(Point p){
        return inRange(p.x,0,mapSize-1)&&inRange(p.y,0,mapSize-1);
    }
    boolean canMoveDiagonal(Point from,Point to){
        Point p1=new Point(from.x,to.y);
        Point p2=new Point(to.x,from.y);
        return (!isBlocker(p1))||(!isBlocker(p2));

    }
    Point move(Point p,Point dir){
        Point target=new Point();
        target.x=p.x+dir.x;
        target.y=p.y+dir.y;
        return target;
    }
    boolean canMove(Point p,Point dir){

        Point target=new Point();
        target.x=p.x+dir.x;
        target.y=p.y+dir.y;

        if(!isInMap(target)){
            return false;
        }
        if(closeSet2[pointIndex(target)]==1){
            return false;
        }
        if(isBlocker(target)){
            return false;
        }
        if(isDiagonal(dir)){
            return canMoveDiagonal(p,target);
        }
        return true;
    }
    //HashMap<Point,Integer> distance=new HashMap<Point, Integer>();
    Deque<Point> openSet=new LinkedList<Point>();
    Round curRound;

    int[] distance2;
    void clearDistance(){
        for (int i = 0; i < distance2.length; i++) {
            distance2[i]=-1;
        }
    }
    void setDistance(Point p,int v){
        distance2[pointIndex(p)]=v;
    }
    int getDistance(Point p){
        int v=distance2[pointIndex(p)];
        if(v==-1){
            throw new RuntimeException();
        }
        return v;
    }
    boolean containDistance(Point p){
        int v=distance2[pointIndex(p)];
        return v!=-1;
    }

    int[] closeSet2;
    int[] mapInfo;
    void clearCloseSet(){
        for (int i = 0; i < closeSet2.length; i++) {
            closeSet2[i]=0;
        }
    }
    void addCloseSet(Point p){
        closeSet2[pointIndex(p)]=1;
    }


//    int getDistance(Point p){
//        if(distance.containsKey(p)){
//            return distance.get(p);
//        }else {
//            System.out.printf("getDistance error");
//            System.exit(0);
//        }
//        return 0;
//    }
    void updateDistance(Point p,int dis){
        if(!containDistance(p)){
            //distance.put(p,dis);
            setDistance(p,dis);
        }else {
            if(getDistance(p)>dis){
                //distance.put(p,dis);
                setDistance(p,dis);
            }
        }
    }

//    Integer getShortestDis(Point target){
//        return distance.getOrDefault(target, null);
//    }

    boolean playerInPos(Point p){
        for (int i = 0; i < players.size(); i++) {
            if(p.equals(players.get(i).pos)){
                return true;
            }
        }
        return false;
    }
    void printMap(){
        for (int y = mapSize-1; y >=0 ; y--) {
            for (int x = 0; x < mapSize; x++) {
                Point p=new Point(x,y);
                if(isBlocker(p)){
                    System.out.printf("B");
                }else if(playerInPos(p)){
                    System.out.printf("P");
                }else{
                    System.out.printf("*");
                }
            }
            System.out.printf("\n");
        }
        System.out.printf("--------------------\n");
    }

    boolean posInRound(Point pos,Round round){
        for (int i = 0; i < round.targets.size(); i++) {
            if(pos.equals(round.targets.get(i))){
                return true;
            }
        }
        return false;
    }
    void printMapRound(Round round){
        for (int y = mapSize-1; y >=0 ; y--) {
            for (int x = 0; x < mapSize; x++) {
                Point p=new Point(x,y);
                if(isBlocker(p)){
                    System.out.printf("B");
                }else if(playerInPos(p)){
                    System.out.printf("P");
                }else if(posInRound(p,round)){
                    System.out.printf("T");
                }
                else if(isSafe(p,round)){
                    System.out.printf("S");
                }
                else{
                    System.out.printf("*");
                }
            }
            System.out.printf("\n");
        }
        System.out.printf("--------------------\n");
    }
    void clearBfs(){
        //closeSet.clear();
        clearCloseSet();
        //distance.clear();
        clearDistance();
        openSet.clear();
    }
    int pointIndex(Point p){
        int v= p.y*mapSize+p.x;
        return v;
    }
    Point indexToPoint(int p){
        Point po=new Point();
        po.x=p%mapSize;
        po.y=p/mapSize;
        return po;
    }
    List<Point> bfsShortestPath(Point start,boolean forward,boolean clear){
        fooTimer.push();
        if(clear){
            clearBfs();
        }
        fooTimer.push();
        List<Point> component=new ArrayList<>();
        //0-1bfs
        openSet.add(start);
        //distance.put(start,0);
        setDistance(start,0);
        while (openSet.size()!=0){
            Point p=openSet.poll();
            component.add(new Point(p.x,p.y));
            //
            //closeSet.add(p);
            addCloseSet(p);
            //System.out.printf("close %d %d %d\n",p.x,p.y,distance.get(p));
            int curDis=getDistance(p);
            for (int i = 0; i < directions.size(); i++) {
                Point dir=directions.get(i);
                if(canMove(p,dir)){
                    Point target=move(p,dir);
                    int newDis=1;
                    //
                    Point judgeSafe;
                    if(forward){
                        judgeSafe=p;
                    }else {
                        judgeSafe=target;
                    }
                    if(isSafe(judgeSafe,curRound)){
                        newDis=0;
                    }
                    //into openset
                    if(!containDistance(target)){
                        if(newDis==0){
                            openSet.addFirst(target);
                        }else {
                            openSet.addLast(target);
                        }
                    }
                    //
                    updateDistance(target,curDis+newDis);
                    //System.out.printf("update %d %d %d\n",target.x,target.y,distance.get(target));
                }
            }
        }
        fooTimer.push();
        return component;
    }

    List<Point> blockersInRound=new ArrayList<>();
    void clearBlockInRound(Round round){

        for (int i = 0; i < mapSize*mapSize; i++) {
            if(mapInfo[i]==1){
                Point p1=indexToPoint(i);
                if(isSafe(p1,round)){
                    blockersInRound.add(p1);
                    mapInfo[i]=0;
                }

            }

        }

//        for (Point p:blockers){
//            if(this.isSafe(p,round)){
//                blockersInRound.add(p);
//            }
//        }
//        for (Point p:blockersInRound){
//            blockers.remove(p);
//        }
    }
    void resetBlockInRound(Round round){

        for (Point p: blockersInRound){
            int index=pointIndex(p);
            mapInfo[index]=1;
        }
        blockersInRound.clear();
//        blockers.addAll(blockersInRound);
//        blockersInRound.clear();
    }

    void playOneRound(){
        curRound=rounds.get(curRoundIndex);
        clearBlockInRound(curRound);
        //log
        //this.printMapRound(curRound);
        long t1=System.currentTimeMillis();
        bfsShortestPath(curRound.safeCenter,false,true);
        long t2=System.currentTimeMillis();
        //System.out.printf("%d\n",t2-t1);

        for (int i = 0; i < players.size(); i++) {
            Player p=players.get(i);
            if(p.hp!=0){
                Point target=curRound.targets.get(i);
                if(p.pos==null||!containDistance(p.pos)){
                    //System.exit(1);
                    System.out.println("error ");
                    break;
                }
                int dis=getDistance(p.pos);
                p.hp=Math.max(p.hp-dis,0);
                if(p.hp!=0){
                    p.pos.x=target.x;
                    p.pos.y=target.y;
                }
            }
        }
        resetBlockInRound(curRound);
    }
//    void dump(){
//        printMap();
//        for(Point p:distance.keySet()){
//            System.out.printf("dump %d %d %d\n",p.x,p.y,distance.get(p));
//        }
//    }
    void playToDeath(){

        long ts=System.currentTimeMillis();
        for (int i = 0; i < roundCount; i++) {
            curRoundIndex =i;
            playOneRound();
        }
        for (int i = 0; i < players.size(); i++) {
            System.out.printf("%d\n",players.get(i).hp);
        }
        long te=System.currentTimeMillis();
        //System.out.printf("playToDeath cost %d ms\n",te-ts);
    }    
}

public class Solution59 {
    static Game readGame(InputStream inputStream){
        Scanner scanner=new Scanner(inputStream);
        Game game=new Game();
        game.mapSize=scanner.nextInt();
        game.playerCount=scanner.nextInt();
        game.blockerCount=scanner.nextInt();
        game.roundCount=scanner.nextInt();
        game.initHp=scanner.nextInt();
        game.init();

        //blockers
        for (int i = 0; i < game.blockerCount; i++) {
            Point p=new Point();
            p.x=scanner.nextInt();
            p.y=scanner.nextInt();
            //game.blockers.add(p);
            game.mapInfo[game.pointIndex(p)]=1;
        }
        //players
        game.players=new ArrayList<Player>();
        for (int i = 0; i < game.playerCount; i++) {
            Player p=new Player();
            p.pos.x=scanner.nextInt();
            p.pos.y=scanner.nextInt();
            p.hp=game.initHp;
            game.players.add(p);
        }
        //rounds
        for (int i = 0; i < game.roundCount; i++) {
            Round r=new Round();
            r.safeCenter.x=scanner.nextInt();
            r.safeCenter.y=scanner.nextInt();
            r.safeRange=scanner.nextInt();
            for (int j = 0; j < game.playerCount; j++) {
                Point point=new Point();
                point.x=scanner.nextInt();
                point.y=scanner.nextInt();
                r.targets.add(point);
            }
            game.rounds.add(r);
        }
        //done
        return game;
    }
    public static void main(String args[]) throws Exception {
        FooTimer fooTimer=new FooTimer();
        fooTimer.push();
        InputStream inputStream=System.in;
        //inputStream=new FileInputStream(new File("data/1.in"));
        Game game=readGame(inputStream);
        game.playToDeath();
        fooTimer.push();
        //game.dump();
    }
}
