import java.util.Scanner;

public class Solution19 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sin = new Scanner(System.in);
        int n = sin.nextInt(); 
        int m = sin.nextInt(); 
        int e = sin.nextInt();
        int k = sin.nextInt();
        int h = sin.nextInt();

        for(int i=0;i<m;i++){
            System.out.println(h);
        }
	}

}
