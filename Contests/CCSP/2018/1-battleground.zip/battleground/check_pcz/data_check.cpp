/*
    data_check.exe fileid
    read data from ../data/fileid.in
    output data info to variable.txt
*/

#include <iostream>
using namespace std;
#include <fstream>
#include <vector>

string fileid;

int n,m,e,f,h;
vector<int> ex,ey;
vector<vector<int>> playerx,playery;
vector<int> cenx,ceny,cenr;


bool st_in_safety = true;
bool ed_in_safety = true;
bool on_board = true;
bool r_in_range = true;


void output_ana()
{
    ofstream fout;
    fout.open("variable.txt",ios::app);
    fout << fileid << '\t' << n << '\t' << m << '\t' << e << '\t' << f << '\t' << h << '\t';
    if(e==0) fout << "no barrier e=0\t";
    else if(e>0 && e<=(n*n)) fout << "0<e<=n*n\t";
    else fout << "ERROR\t";
    fout << st_in_safety << '\t' << ed_in_safety << '\t';
    if(1<=n && n<=20) fout << "1<=n<=20\t";
    else if(20<n && n<=100) fout << "20<n<=100\t";
    else fout << "ERROR\t";
    if(1<=m && m<=100) fout << "1<=m<=100\t";
    else if(100<m && m<=5000) fout << "100<m<=5000\t";
    else fout << "ERROR\t";
    if(f>=1 && f<=10) fout << "1<=f<=10\t";
    else fout << "ERROR\t";
    if(on_board) fout << "0<=a,b,u,v<n\t";
    else fout << "ERROR\t";
    if(h>0 && (2*h)<=(5*n)) fout << "0<h<=2.5n\t";
    else fout << "ERROR\t";
    if(r_in_range) fout << "0<r<=100";
    else fout << "ERROR";
    fout << endl;
    fout.close();
}

bool safe(int x, int y, int t) // whether (x,y) in the safety area of t-th round
{
    int sqrdist = (x - cenx[t]) * (x - cenx[t]) + (y - ceny[t]) * (y - ceny[t]);
    if(sqrdist<=(cenr[t]*cenr[t])) return true;
    else return false;
}

void read_data()
{
    ifstream fin;
    fin.open("../data/" + fileid + ".in");
    int x,y,r;
    fin >> n >> m >> e >> f >> h;
    for(int i=0; i<e; i++)
    {
        fin >> x >> y;
        if(x<0 || x>=n || y<0 || y>=n) on_board = false;
        ex.push_back(x);
        ey.push_back(y);
    }
    playerx.resize(f+1);
    playery.resize(f+1);
    for(int i=0; i<m; i++)
    {
        fin >> x >> y;
        if(x<0 || x>=n || y<0 || y>=n) on_board = false;
        playerx[0].push_back(x);
        playery[0].push_back(y);
    }
    for(int i=1; i<=f; i++)
    {
        fin >> x >> y >> r;
        if(x<0 || x>=n || y<0 || y>=n) on_board = false;
        if(r<=0 || r>100) r_in_range = false;
        cenx.push_back(x);
        ceny.push_back(y);
        cenr.push_back(r);
        for(int j=0; j<m; j++)
        {
            fin >> x >> y;
            if(x<0 || x>=n || y<0 || y>=n) on_board = false;
            playerx[i].push_back(x);
            playery[i].push_back(y);
        }
    }
    fin.close();
}

void check_in_safety()
{
    for(int i=0; i<f; i++)
        for(int j=0; j<m; j++)
            if(!safe(playerx[i][j],playery[i][j],i))
                st_in_safety = false;
    for(int i=0; i<f; i++)
        for(int j=0; j<m; j++)
            if(!safe(playerx[i+1][j],playery[i+1][j],i))
                ed_in_safety = false;
}

int main(int argc, char* argv[])
{
    if(argc>1) fileid = argv[1];
    else fileid = "1";
    read_data();
    check_in_safety();
    output_ana();
    return 0;
}
