#include <iostream>
using namespace std;
#include <vector>
#include <queue>

#define MAXN 110

int n,m,e,f,h;
bool barrier[MAXN][MAXN];
vector<vector<int>> playerx,playery;
vector<int> cenx,ceny,cenr;
vector<int> playerh;
int now_round;

bool on_board(int x, int y)
{
    if(x<0 || x>=n || y<0 || y>=n) return false;
    else return true;
}

bool safe(int x, int y, int t) // whether (x,y) in the safety area of t-th round
{
    int sqrdist = (x - cenx[t]) * (x - cenx[t]) + (y - ceny[t]) * (y - ceny[t]);
    if(sqrdist<=(cenr[t]*cenr[t])) return true;
    else return false;
}

bool safe(int x, int y)
{
    return safe(x,y,now_round);
}

void read_data()
{
    int x,y,r;
    cin >> n >> m >> e >> f >> h;
    playerh.resize(m);
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            barrier[i][j] = false;
    for(int i=0; i<m; i++)
        playerh[i] = h;
    for(int i=0; i<e; i++)
    {
        cin >> x >> y;
        barrier[x][y] = true;
    }
    playerx.resize(f+1);
    playery.resize(f+1);
    for(int i=0; i<m; i++)
    {
        cin >> x >> y;
        playerx[0].push_back(x);
        playery[0].push_back(y);
    }
    for(int i=1; i<=f; i++)
    {
        cin >> x >> y >> r;
        cenx.push_back(x);
        ceny.push_back(y);
        cenr.push_back(r);
        for(int j=0; j<m; j++)
        {
            cin >> x >> y;
            playerx[i].push_back(x);
            playery[i].push_back(y);
        }
    }
}

void gogogo()
{
    int dist[n][n];
    int dx[8] = {0, -1, 0, 1, -1, -1, 1, 1};
    int dy[8] = {1, 0, -1, 0, 1, -1, -1, 1};
    queue<int> qx,qy;
    for(int i=0; i<n; i++)
        for(int j=0; j<n; j++)
            if(safe(i,j))
            {
                dist[i][j] = 0;
                qx.push(i);
                qy.push(j);
            }
            else dist[i][j] = -1;
    while(!qx.empty())
    {
        int x = qx.front();
        int y = qy.front();
        qx.pop();
        qy.pop();
        for(int i=0; i<8; i++)
        {
            int tx = x + dx[i];
            int ty = y + dy[i];
            if(!on_board(tx,ty) || dist[tx][ty]>=0) continue;
            if(dx[i]!=0 && dy[i]!=0 && barrier[x+dx[i]][y] && !safe(x+dx[i],y) && barrier[x][y+dy[i]] && !safe(x,y+dy[i])) continue;
            dist[tx][ty] = dist[x][y] + 1;
            if(!barrier[tx][ty])
            {
                qx.push(tx);
                qy.push(ty);
            }
        }
    }
    for(int i=0; i<m; i++)
        if(playerh[i]>0)
        {
            int x = playerx[now_round][i];
            int y = playery[now_round][i];
            if(dist[x][y]==-1 || dist[x][y]>=playerh[i]) playerh[i] = 0;
            else playerh[i] -= dist[x][y];
        }
}


int main(int argc, char* argv[])
{
    read_data();
    for(now_round=0; now_round<f; now_round++)
        gogogo();
    for(int i=0; i<m; i++)
        cout << playerh[i] << endl;
    return 0;
}
