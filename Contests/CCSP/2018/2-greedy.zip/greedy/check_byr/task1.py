#encoding=utf-8
import sys

edgevec = []

def dfs(node, last, visited):
	if visited.count(node) > 0:
		print('error find ring', visited)
		sys.exit(-1)
	visited.append(node)
	for nx in edgevec[node]:
		if nx != last:
			dfs(nx, node, visited)

def check(filename):
	edge = set()
	with open(filename, 'r') as f:
		firstline = f.readline().split(' ')
		# n <= 2000,m <= 100000
		n, m = [int(x) for x in firstline]
		if (n < 1) or (n > 2000):
			print('error n: ', n)
			sys.exit(-1)
		if (m < 1) or (m > 100000):
			print('error m: ', m)
			sys.exit(-1)
		for i in range(n+1):
			edgevec.append([])
		# apply to all cases
		for i in range(m):
			line = f.readline().split(' ')
			u, v = [int(x) for x in line]
			if (u > v):
				tmp = u
				u = v
				v = tmp
			if (u == v):
				print('error', i, 'line', 'u == v', u)
				sys.exit(-1)
			if (u,v) in edge:
				print('error', i, 'line', 'same edge', u, v)
				sys.exit(-1)
			edge.add((u, v))
			edgevec[u].append(v)
			edgevec[v].append(u)
	# no ring
	for i in range(1, n+1):
		dfs(i, -1, [])
	# print(edgevec)
	# print(edge)
	# print(len(edge))
	print('no error')




def main():
	filename = sys.argv[1]
	check(filename)

if __name__ == '__main__':
	main()