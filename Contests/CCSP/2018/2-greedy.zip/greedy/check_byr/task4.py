#encoding=utf-8
import sys

def check(filename):
	edge = set()
	with open(filename, 'r') as f:
		firstline = f.readline().split(' ')
		# n <= 100000,m <= 500000
		n, m = [int(x) for x in firstline]
		if (n < 1) or (n > 100000):
			print('error n: ', n)
			sys.exit(-1)
		if (m < 1) or (m > 500000):
			print('error m: ', m)
			sys.exit(-1)
		# apply to all cases
		for i in range(m):
			line = f.readline().split(' ')
			u, v = [int(x) for x in line]
			if (u > v):
				tmp = u
				u = v
				v = tmp
			if (u == v):
				print('error', i, 'line', 'u == v', u)
				sys.exit(-1)
			if (u,v) in edge:
				print('error', i, 'line', 'same edge', u, v)
				sys.exit(-1)
			edge.add((u, v))
	print('no error')




def main():
	filename = sys.argv[1]
	check(filename)

if __name__ == '__main__':
	main()