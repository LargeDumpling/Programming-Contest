#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <set>
using namespace std;
const int N = 100100;
int n, m;
std::vector<int> edge[N];
int degree[N];
set<int> rest;

void build(int a, int b) {
	edge[a].push_back(b);
	degree[a]++;
}

void erase(int node, int erased){
	for (int& pot : edge[node]){
		if (pot == erased){
			pot = *(--edge[node].end());
			edge[node].pop_back();
			break;
		}
	}
	degree[node]--;
	// printf("%d %d edge deg\n", edge[node].size(), degree[node]);
}

void erase(int node){
	for (int pot : edge[node])
		erase(pot, node);
}

int fakeerase(int node){
	int re = 0;
	for (int pot : edge[node]){
		if (degree[pot] == 2)
			re++;
	}
	return re;
}

void eliminate() {
	for (int i = 1; i <= n; i++)
		rest.insert(i);
	while (rest.size() > 0){
		// printf("%d rest size\n", rest.size());
		int flag = 0;
		for (int node : rest){
			if (degree[node] == 0){
				printf("%d\n", node);
				rest.erase(node);
				flag = 1;
				break;
			}
		}
		if (!flag){
			for (int node : rest){
				if (degree[node] == 1){
					printf("%d\n", node);
					rest.erase(node);
					assert(edge[node].size() == 1); 
					int pot = *edge[node].begin();
					rest.erase(pot);
					erase(pot);
					flag = 2;
					break;
				}
			}
		}
		if (!flag){
			int maxdeg = 0;
			for (int node : rest){
				if (degree[node] > maxdeg)
					maxdeg = degree[node];
			}
			set<int> candidate;
			for (int node : rest){
				if (degree[node] == maxdeg)
					candidate.insert(node);
			}
			// printf("%d %d maxdeg\n", maxdeg, candidate.size());
			if (candidate.size() > 1){
				int max1 = 0;
				for (int node : candidate){
					int deg1 = fakeerase(node);
					if (deg1 > max1)
						max1 = deg1;
				}
				// printf("%d max1\n", max1);
				auto it = candidate.end();
				for (; it != candidate.begin(); ){
					--it;
					int deg1 = fakeerase(*it);
					if (deg1 == max1){
						// printf("%d del\n", *it);
						rest.erase(*it);
						erase(*it);
						break;
					}
				}
			} else {
				int node = *(--candidate.end());
				// printf("%d del\n", node);
				rest.erase(node);
				erase(node);
			}
		}
	}
}

int main(){
	scanf("%d%d", &n, &m);
	for (int i = 0; i < m; i++){
		int a, b;
		scanf("%d%d", &a, &b);
		build(a, b);
		build(b, a);
	}
	eliminate();
	return 0;
}