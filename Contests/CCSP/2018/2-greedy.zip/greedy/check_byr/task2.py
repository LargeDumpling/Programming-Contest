#encoding=utf-8
import sys

def check(filename):
	edge = set()
	with open(filename, 'r') as f:
		firstline = f.readline().split(' ')
		# n <= 2000,m <= 100000
		n, m = [int(x) for x in firstline]
		if (n < 1) or (n > 2000):
			print('error n: ', n)
			sys.exit(-1)
		if (m < 1) or (m > 100000):
			print('error m: ', m)
			sys.exit(-1)
		# apply to all cases
		for i in range(m):
			line = f.readline().split(' ')
			u, v = [int(x) for x in line]
			if (u > v):
				tmp = u
				u = v
				v = tmp
			if (u == v):
				print('error', i, 'line', 'u == v', u)
				sys.exit(-1)
			if (u,v) in edge:
				print('error', i, 'line', 'same edge', u, v)
				sys.exit(-1)
			edge.add((u, v))
	# triangle
	for i in range(1, n+1):
		for j in range(i+1, n+1):
			for k in range(j+1, n+1):
				if ((i, j) in edge) and ((j, k) in edge) and (not ((i, k) in edge)):
					print('error triangle', i, j, k)
					sys.exit(-1)
	print('no error')




def main():
	filename = sys.argv[1]
	check(filename)

if __name__ == '__main__':
	main()