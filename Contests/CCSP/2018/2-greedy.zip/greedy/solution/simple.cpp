#include <iostream>
using namespace std;
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <cstdlib>
#include <ctime>

#define MAXN 100100

vector<int> neigh[MAXN];
int d[MAXN];
bool del[MAXN];
int num;

int n,m,u,v;

int main()
{
    scanf("%d%d",&n,&m);
    for(int i=0; i<m; i++)
    {
        scanf("%d%d",&u,&v);
        neigh[u].push_back(v);
        neigh[v].push_back(u);
    }
    for(int i=1; i<=n; i++)
        d[i] = neigh[i].size();
    num = 0;
    while(num<n)
    {
        int p = 0;
        for(int i=1; i<=n; i++)
            if(!del[i] && d[i]==0)
        {
            p = i;
            break;
        }
        if(p>0)
        {
            del[p] = true;
            for(int i=0; i<neigh[p].size(); i++)
                d[neigh[p][i]]--;
            printf("%d\n",p);
            num++;
            continue;
        }
        for(int i=1; i<=n; i++)
            if(!del[i] && d[i]==1)
        {
            p = i;
            break;
        }
        if(p>0)
        {
            int q;
            for(int i=0; i<neigh[p].size(); i++)
            {
                q = neigh[p][i];
                if(!del[q]) break;
            }
            del[p] = del[q] = true;
            printf("%d\n",p);
            num += 2;
            for(int i=0; i<neigh[q].size(); i++)
                d[neigh[q][i]]--;
            continue;
        }
        int maxd = 0;
        int maxid = 0;
        for(int i=n; i>0; i--)
            if(!del[i] && d[i]>=maxd)
            {
                if(d[i]>maxd)
                {
                    maxid = i;
                    maxd = d[i];
                }
            }
        del[maxid] = true;
        num++;
        for(int i=0; i<neigh[maxid].size(); i++)
                d[neigh[maxid][i]]--;
    }
    return 0;
}
