#include <iostream>
using namespace std;
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
#include <cstdlib>
#include <ctime>

struct edge_type{
    int st,ed,next;
};

struct node_type{
    int id,head,degree;
};


vector<edge_type> edge;
vector<node_type> g;
vector<int> ans;
int n,m;

struct node_info{
    int id,degree,nxt2;
    node_info(int nid = 0, int ndegree = 0, int nnxt2 = 0):id(nid), degree(ndegree), nxt2(nnxt2){}
    void operator =(const node_info &tmp)
    {
        id = tmp.id;
        degree = tmp.degree;
        nxt2 = tmp.nxt2;
    }

    bool operator <(const node_info &tmp)   // id < nxt2 < degree
    {
        if(degree==tmp.degree){
                if(nxt2==tmp.nxt2) return(id<tmp.id);
                else return(nxt2<tmp.nxt2);
        }
        else return(degree<tmp.degree);
    }
};


void add_edge(int u, int v)
{
    edge_type e;
    e.st = u;
    e.ed = v;
    e.next = g[u].head;
    g[u].head = edge.size();
    edge.push_back(e);
    e.st = v;
    e.ed = u;
    e.next = g[v].head;
    g[v].head = edge.size();
    edge.push_back(e);
    g[u].degree++;
    g[v].degree++;
}

void read_data()
{
    cin >> n >> m;
    g.resize(n);
    for(int i=0; i<n; i++)
    {
        g[i].id = i;
        g[i].head = -1;
        g[i].degree = 0;
    }
    for(int i=0; i<m; i++)
    {
        int u,v;
        cin >> u >> v;
        add_edge(u-1,v-1);
    }
}

void bdone_del(int u, vector<node_info> &b, vector<bool> &del, priority_queue<int,vector<int>,greater<int>> &que0, priority_queue<int,vector<int>,greater<int>> &que1)
{
    del[u] = true;
    int j = g[u].head;
    while(j>=0)
    {
        int v = edge[j].ed;
        if(!del[v])
        {
            b[v].degree--;
            if(b[u].degree==2) b[v].nxt2--;
            if(b[v].degree==2||b[v].degree==1) // deleting edge from linked list will be better
                for(int k=g[v].head; k>=0; k=edge[k].next)
                {
                    int w = edge[k].ed;
                    if(!del[w])
                    {
                        b[w].nxt2 += (b[v].degree * 2 - 3);
                    }
                }
            if(b[v].degree==1) que1.push(v);
            else if(b[v].degree==0) que0.push(v);
        }
        j = edge[j].next;
    }
}


void bdone()
{
    vector<node_info> b;
    b.resize(n);
    for(int i=0; i<n; i++)
    {
        b[i].id = i;
        b[i].degree = g[i].degree;
        b[i].nxt2 = 0;
    }
    for(int i=0; i<n; i++)
        if(g[i].degree==2)
        {
            for(int j=g[i].head; j>=0; j=edge[j].next)
                b[edge[j].ed].nxt2++;
        }
    vector<bool> del;
    del.resize(n);
    for(int i=0; i<n; i++)
        del[i] = false;
    priority_queue<int,vector<int>,greater<int>> que0;
    priority_queue<int,vector<int>,greater<int>> que1;
    for(int i=0; i<n; i++)
        if(b[i].degree==0)
        {
            del[i] = true;
            ans.push_back(i);
        }
        else if(b[i].degree==1) que1.push(i);
    while(true)
    {
        if(!que0.empty())
        {
            int u = que0.top();
            que0.pop();
            if(del[u]) continue;
            del[u] = true;
            ans.push_back(u);
        }
        else if(!que1.empty())
        {
            int u = que1.top();
            que1.pop();
            if(b[u].degree==0 || del[u]) continue;
            int v;
            for(int j=g[u].head; j>=0; j=edge[j].next)
            {
                v = edge[j].ed;
                if(!del[v]) break;
            }
            bdone_del(u,b,del,que0,que1);
            bdone_del(v,b,del,que0,que1);
            ans.push_back(u);
        }
        else{
            int tid = 0;
            while(del[tid] && tid<n) tid++;
            if(tid==n) break;
            for(int i=tid+1; i<n; i++)
                if(!del[i] && b[tid]<b[i]) tid = i;
            bdone_del(tid,b,del,que0,que1);
        }
    }
}

void output_ans()
{
    for(int i=0; i<ans.size(); i++)
        cout << ans[i] + 1 << endl;
}


int main()
{
    read_data();
    bdone();
    output_ans();
    return 0;
}
