import random
import sys
import os
import time
import json
import math

def printf(*arg, **argw):
	print(*arg, **argw)
	sys.stdout.flush()

random.setstate(eval(open('random_state').read()))

a_list = [
	(3, 1),
	(5, 1),
	(10, 0),
	(15, 1),
	(20, 0),
	(150, 1),
	(200, 0),
	(300, 1),
	(500, 0),
	(2000, 1),
	(3000, 0),
	(5000, 1),
	(10000, 0),
	(10000, 1),
	(12000, 1),
	(15000, 0),
	(15000, 1),
	(18000, 1),
	(20000, 0),
	(20000, 1)
]
m_n = 1.
p_m_n = 1.6407843301899723
q_n = 20.
js_data = []

def gen(cn, n, qm):
	last = [{}, {}]
	def ins(u, v):
		if u < 0:
			return
		deg[v] += 1
		edges[u].append(v)
	printf('gen %d.in' % cn)
	with open('data/%d.in' % cn, 'w') as f:
		p_m = int(math.log(n) / math.log(p_m_n) + 1e-8)
		m = int(m_n * n + 1e-8)
		p = p_m * m
		q = int(q_n * n + 1e-8) * qm
		edges = [[] for i in range(p)]
		deg = [0 for i in range(p)]
		js_data.append({
			'cases' : [cn],
			'args' : {'n' : n, 'm' : m, 'p' : p, 'q' : q}
		})
		f.write('%d %d %d %d\n' % (n, m, p, q))
		arr = list(range(m))
		random.shuffle(arr)
		ori = []
		for i in range(m):
			for j in range(p_m):
				idx = i * p_m + j
				if j != 0:
					ins(idx - 1, idx)
				tx, var, tp = arr[i], random.randint(0, n - 1), random.randint(0, 1)
				if tp == 0:
					ins(last[1].get(var, -1), idx)
					last[0].setdefault(var, [])
					last[0][var].append(idx)
				else:
					if len(last[0].get(var, [])) == 0:
						ins(last[1].get(var, -1), idx)
					else:
						for k in last[0][var]:
							ins(k, idx)
					last[0][var] = []
					last[1][var] = idx
				ori.append((tp, var + 1, tx + 1))
		pool = []
		for i in range(p):
			if deg[i] == 0:
				pool.append(i)
		while len(pool) > 0:
			l = len(pool) - 1
			cur = random.randint(0, l)
			c = pool[cur]
			pool[cur] = pool[l]
			pool.pop()
			for v in edges[c]:
				deg[v] -= 1
				if deg[v] == 0:
					pool.append(v)
			f.write('%s\n' % ' '.join(map(str, ori[c])))
		for i in range(q):
			while True:
				x = random.randint(1, m)
				y = random.randint(1, m)
				if x != y:
					break
			f.write('%d %d\n' % (x, y))
	printf('gen %d.ans' % cn)
	ti = time.time()
	os.system('%s < data/%d.in > data/%d.ans' % (
		os.path.join('mulab', 'brute.exe'),
		cn,
		cn
	))
	printf('finished %f' % (time.time() - ti))
	fin = list(map(int, open('data/%d.ans' % cn).readline().split()))
	pos = [0] * m
	for i, v in enumerate(fin):
		pos[v - 1] = i
	dis = 0
	for i, v in enumerate(arr):
		dis += abs(i - pos[v])
	with open('arr.tmp', 'a') as f:
		f.write('%s\n' % ' '.join(map(lambda x : str(x + 1), arr)))
	printf('move rate = %f' % (float(dis) / ((m + 1) // 2 * (m // 2) * 2)))

if __name__ == '__main__':
	os.system('g++ -O2 mulab/brute.cpp -o mulab/brute.exe -Wall -std=c++14')
	open('arr.tmp', 'w')
	for i, (n, j) in enumerate(a_list):
		gen(i + 1, n, j)
	conf = json.loads(open('conf.json', 'rb').read().decode('utf-8'))
	conf['data'] = js_data
	open('conf.json', 'wb').write(json.dumps(conf, indent = 2, sort_keys = True).encode('utf-8'))
	