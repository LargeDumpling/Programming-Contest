keys = ['n', 'm', 'p', 'q']
ret = [["测试点"] + list(map(lambda name : '$%s=$' % name, keys))]
for datum in prob['data']:
	args = datum['args']
	row = [
		','.join(map(str, datum['cases']))
	] + list(map(lambda name : '$%s$' % tools.hn(args[name]), keys))
	ret.append(row)
return merge_ver(ret)
