#include <iostream>
#include <memory>
#include <sstream>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>

bool IsNumber(const std::string& str) {
  for (char ch : str) {
    if (!(ch >= '0' && ch <= '9')) {
      return false;
    }
  }
  return true;
}

class Expression;

typedef std::shared_ptr<Expression> ExprPtr;
typedef std::unordered_map<std::string, ExprPtr> ExprMap;
typedef std::vector<ExprPtr> ExprList;

class Expression : public std::enable_shared_from_this<Expression> {
 public:
  Expression() {}
  virtual ~Expression() {}
  virtual std::string ToString() const = 0;
  virtual ExprPtr Evaluate(ExprMap& env) = 0;
  virtual ExprPtr Apply(ExprList args, ExprMap env) const { return nullptr; }
  virtual ExprPtr Substitute(ExprMap env) { return shared_from_this(); }
  virtual bool IsAtom() const { return false; }
  virtual bool Equals(ExprPtr other) const { return false; }

  const static ExprPtr kFalse;
  const static ExprPtr kTrue;
 protected:
};

class Atom : public Expression {
 public:
  Atom(const std::string& value = "") : value_(value) {}
  virtual ~Atom() {}
  virtual std::string ToString() const override { return value_; }
  virtual ExprPtr Evaluate(ExprMap& env) override {
    if (IsNumber(value_)) {
      return Expression::Substitute(env);
    } else {
      return Substitute(env);
    }
  }
  virtual ExprPtr Apply(ExprList args, ExprMap env) const override;
  virtual ExprPtr Substitute(ExprMap env) override {
    auto item = env.find(value_);
    if (item != env.end()) {
      return item->second;
    } else {
      return Expression::Substitute(env);
    }
  }
  virtual bool IsAtom() const override { return true; }
  virtual bool Equals(ExprPtr other) const override {
    auto other_atom = std::dynamic_pointer_cast<Atom>(other);
    return other_atom && value_ == other_atom->value_;
  }
 protected:
  std::string value_;
};

class List : public Expression {
 public:
  List() : values_() {}
  List(ExprList values) : values_(values) {}
  virtual ~List() {}
  virtual std::string ToString() const override {
    std::ostringstream string;
    string << "(";
    bool first = true;
    for (ExprPtr value : values_) {
      if (first) {
        first = false;
      } else {
        string << " ";
      }
      string << value->ToString();
    }
    string << ")";
    return string.str();
  }
  virtual ExprPtr Evaluate(ExprMap& env) override;
  virtual ExprPtr Apply(ExprList args, ExprMap env) const override;
  virtual ExprPtr Substitute(ExprMap env) override;
  virtual bool Equals(ExprPtr other) const override {
    auto other_list = std::dynamic_pointer_cast<List>(other);
    if (!other_list) {
      return false;
    }
    if (values_.size() != other_list->values_.size()) {
      return false;
    }
    for (int i = 0; i < values_.size(); i++) {
      if (!values_[i]->Equals(other_list->values_[i])) {
        return false;
      }
    }
    return true;
  }

  friend class Atom;
 protected:
  ExprList values_;
};

class Literal : public Expression {
 public:
  Literal(ExprPtr expr) : expr_(expr) {}
  virtual ~Literal() {}
  virtual std::string ToString() const override { return "'" + expr_->ToString(); }
  virtual ExprPtr Evaluate(ExprMap& env) override {
    return expr_;
  }
  virtual bool IsAtom() const override { return expr_->IsAtom(); }
 protected:
  ExprPtr expr_;
};

class Interpreter {
 public:
  Interpreter() { AddBuiltins(); }
  ~Interpreter() {}
  ExprPtr Parse(const std::string& expr_str) const;
  ExprPtr Evaluate(ExprPtr expr) {
    return expr->Evaluate(env_);
  }
 private:
  void AddBuiltins();
  ExprMap env_;
};

int stoi(const std::string&  str)
{
    int sum = 0;
    int len = str.length();
    for(int i=0; i<len; i++)
    {
        sum = sum * 10 + str[i] - '0';
    }
    return sum;
}

std::string to_string (int val)
{
    std::string str;
    std::vector<int> tmp;
    if(val==0)
    {
        str.append(1,'0');
        return str;
    }
    while(val>0)
    {
        tmp.push_back(val%10);
        val/=10;
    }
    for(int i=tmp.size()-1; i>=0; i--)
    {
        str.append(1,tmp[i]+'0');
    }
    return str;
}

ExprPtr Atom::Apply(ExprList args, ExprMap env) const {
  std::string func_name = value_;
  ExprPtr result;
  if (func_name == "+" || func_name == "-" || func_name == "*" || func_name == "/") {
    int op1 = stoi(args[0]->ToString());
    int op2 = stoi(args[1]->ToString());
    char op = func_name[0];
    int res;
    switch (op) {
      case '+': {
        res = op1 + op2;
        break;
      }
      case '-': {
        res = op1 - op2;
        break;
      }
      case '*': {
        res = op1 * op2;
        break;
      }
      case '/': {
        res = op1 / op2;
        break;
      }
    }
    result = std::make_shared<Atom>(to_string(res));
  } else if (func_name == "eq?") {
    if (args[0]->Equals(args[1])) {
      result = kTrue;
    } else {
      result = kFalse;
    }
  }
  return result;
}

ExprPtr List::Evaluate(ExprMap& env) {
  if (values_.empty()) {
    return shared_from_this();
  }
  std::string command = values_[0]->ToString();
  ExprPtr result;
  if (command == "quote") {
    result = values_[1];
  } else if (command == "define") {
    auto name_atom = std::static_pointer_cast<Atom>(values_[1]);
    std::string name = name_atom->ToString();
    auto value = values_[2]->Evaluate(env);
    env[name] = value;
    result = values_[0];
  } else if (command == "lambda") {
    result = shared_from_this();
  } else if (command == "cond") {
    for (int i = 1; i < values_.size(); i++) {
      auto branch = std::static_pointer_cast<List>(values_[i]);
      auto cond = branch->values_[0]->Evaluate(env);
      if (cond->Equals(kTrue)) {
        result = branch->values_[1]->Evaluate(env);
        break;
      }
    }
  } else {  // function call
    ExprPtr func = values_[0]->Evaluate(env);
    //std::clog << "Function: " << func->ToString() << std::endl;
    //std::clog << "Arguments:";
    ExprList args;
    for (int i = 1; i < values_.size(); i++) {
      args.push_back(values_[i]->Evaluate(env));
      //std::clog << ' ' << args.back()->ToString();
    }
    //std::clog << std::endl;
    result = func->Apply(args, env)->Evaluate(env);
  }
  return result;
}

ExprPtr List::Apply(ExprList args, ExprMap env) const {
  ExprMap func_env;
  auto param_list = std::static_pointer_cast<List>(values_[1]);
  for (int i = 0; i < param_list->values_.size(); i++) {
    auto param_name = param_list->values_[i];
    func_env[param_name->ToString()] = args[i];
  }
  auto func_body = std::static_pointer_cast<List>(values_[2]);
  return func_body->Substitute(func_env);
}

ExprPtr List::Substitute(ExprMap env) {
  ExprList result;
  for (ExprPtr element : values_) {
    result.push_back(element->Substitute(env));
  }
  return std::make_shared<List>(result);
}

ExprPtr Interpreter::Parse(const std::string& expr_str) const {
  bool literal = false;
  std::string token;
  std::stack<bool> literals;
  std::stack<ExprList> tokens;
  literals.emplace();
  tokens.emplace();
  for (char ch : expr_str) {
    if (ch == '\'') {
      literal = true;
    } else if (ch == '(') {
      literals.emplace(literal);
      tokens.emplace();
      literal = false;
    } else if (ch == ')' || ch == ' ') {
      if (!token.empty()) {
        ExprPtr expr = std::make_shared<Atom>(token);
        if (literal) {
          expr = std::make_shared<Literal>(expr);
        }
        tokens.top().push_back(expr);
        literal = false;
        token.clear();
      }
      if (ch == ')') {
        ExprPtr expr = std::make_shared<List>(tokens.top());
        tokens.pop();
        if (literals.top()) {
          expr = std::make_shared<Literal>(expr);
        }
        literals.pop();
        tokens.top().push_back(expr);
      }
    } else {  // ch should be letters, digits, or operators
      token += ch;
    }
  }
  if (!token.empty()) {
    ExprPtr expr = std::make_shared<Atom>(token);
    if (literal) {
      expr = std::make_shared<Literal>(expr);
    }
    return expr;
  } else {
    return tokens.top().front();
  }
}

void Interpreter::AddBuiltins() {
  env_["False"] = Expression::kFalse;
  env_["True"] = Expression::kTrue;
  env_["+"] = std::make_shared<Atom>("+");
  env_["-"] = std::make_shared<Atom>("-");
  env_["*"] = std::make_shared<Atom>("*");
  env_["/"] = std::make_shared<Atom>("/");
  env_["eq?"] = std::make_shared<Atom>("eq?");
}

const ExprPtr Expression::kFalse = std::make_shared<Atom>("False");
const ExprPtr Expression::kTrue = std::make_shared<Atom>("True");

int main() {
  Interpreter interpreter;
  /*std::vector<std::string> program({
    "(define twice (lambda (x) (+ x x)))",
    "(define repeat (lambda (f) (lambda (x) (f (f x)))))",
    "(repeat twice)",
    "((repeat twice) 1)",
  });*/
  //for (std::string line : program) {
  std::string line;
  while (std::getline(std::cin, line)) {
    //std::clog << "# " << line << std::endl;
    ExprPtr expr = interpreter.Parse(line);
    ExprPtr result = interpreter.Evaluate(expr);
    std::cout << result->ToString() << std::endl;
  }
}
