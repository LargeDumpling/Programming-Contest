#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
#include <queue>

using namespace std;

namespace Solve
{
    map<string, string> global_context;

    bool isNumber(const char *s, const char *t)
    {
        while(s != t)
        {
            if (*s < '0' || '9' < *s)
                return false;
            s ++;
        }
        return true;
    }
    bool isNumber(const string& x)
    {
        const char *s = x.c_str();
        const char *t = s + x.length();
        return isNumber(s, t);
    }
    string readToken(const char *&k, const char *e)
    {
        const char *s = k;
        while(isspace(*s)) s++;
        const char *t = s+1;
        while(t != e && !isspace(*t)) t++;
        k = t;
        while(k != e && isspace(*k)) k ++;
        return string(s, t-s);
    }
    vector<string> parseArgs(const string& line)
    {
        const char *s = line.c_str();
        const char *t = s + line.length();
        vector<string> rst;
        while(s != t)
        {
            if (s[0] == '(') {
                int c = 0;
                const char *m = s;
                while(true)
                {
                    if (*m == '(') c ++;
                    else if (*m == ')') c --;
                    if (c == 0) break;
                    m ++;
                }
                rst.push_back(string(s+1, m-s-1));
                s = m+1;
                while(s != t && isspace(*s)) s ++;
            } else {
                rst.push_back(readToken(s, t));
            }
        }
        // cout << "parseArgs : [" << line << "]" << endl;
        // for(int i=0;i<(int)rst.size();i++)
        //     cout << rst[i] << " | ";
        // cout << endl;
        return rst;
    }
    // string skipSpace(const string& line, int count)
    // {
    //     const char *s = line.c_str();
    //     const char *t = s + line.length();
    //     while(count)
    //     {
    //         if(isspace(*s)) count --;
    //         s ++;
    //     }
    //     while(s != t && isspace(*s)) s ++;
    //     return string(s, t-s);
    // }
    int run(const string& cmd,
            const map<string, int>& lamda_context = map<string, int>(),
            const vector<int>& lamda_args = vector<int>() // lamda expr args
        )
    {
        // cout << "run : [" << cmd << "]" << endl;
        vector<string> args = parseArgs(cmd);
        if (isNumber(args[0])) return atoi(args[0].c_str());

        const string& name = args[0];
        if (lamda_context.find(name) != lamda_context.end()) {
            return lamda_context.at(name);
        }
        
        if (name == "lambda") {
            map<string, int> new_context = lamda_context;
            vector<string> pas = parseArgs(args[1]);
            for(int i=0;i<(int)pas.size();i++)
                new_context[pas[i]] = lamda_args[i];
            return run(args[2], new_context);
        } else if (name == "cond") {
            for(int i=1;i<(int)args.size();i++)
            {
                vector<string> xs = parseArgs(args[i]);
                if(run(xs[0], lamda_context)) return run(xs[1], lamda_context);
            }
            return -1; // should not run here
        } else if (name == "True") {
            return 1;
        } else if (name == "False") {
            return 0;
        } else if (name == "+") {
            int a = run(args[1], lamda_context);
            int b = run(args[2], lamda_context);
            return a+b;
        } else if (name == "-") {
            int a = run(args[1], lamda_context);
            int b = run(args[2], lamda_context);
            return a-b;
        } else if (name == "*") {
            int a = run(args[1], lamda_context);
            int b = run(args[2], lamda_context);
            return a*b;
        } else if (name == "/") {
            int a = run(args[1], lamda_context);
            int b = run(args[2], lamda_context);
            return a/b;
        } else if (name == "eq?") {
            int a = run(args[1], lamda_context);
            int b = run(args[2], lamda_context);
            return a==b;
        } else {
            //cout << "get name " << name << endl;
            string func = cmd[0] == '(' ? args[0] : global_context.at(name);
            vector<int> pas;
            for(int i=1;i<(int)args.size();i++)
                pas.push_back(run(args[i], lamda_context));
            return run(func, cmd[0] == '(' ? lamda_context : map<string, int>(), pas);
        }
    }
    void process(const string& cmd)
    {
        // cout << "=============" << endl;
        if (cmd[0] == '(')
        {
            string line = cmd.substr(1, cmd.length()-2);
            vector<string> args = parseArgs(line);
            if (args[0] == "define") {
                global_context[args[1]] = args[2];
                cout << "define" << endl;
            } else {
                cout << run(line) << endl;
            }
        } else {
            if (isNumber(cmd)) cout << cmd << endl;
            else {
                cout << run(global_context[cmd]) << endl;
            }
        }
    }
    void solve()
    {
        char buf[210];
        while(fgets(buf, sizeof(buf), stdin))
        {
            int len = strlen(buf);
            while(len && isspace(buf[len-1]))
            {
                len--;
            }
            buf[len]='\0';
            if (len == 0) break;
            process(buf);
        }
    }
}

int main(int argc, char* argv[])
{
    Solve::solve();
    return 0;
}
