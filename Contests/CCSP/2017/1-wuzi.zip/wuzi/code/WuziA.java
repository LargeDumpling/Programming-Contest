import java.io.*;
import java.util.Scanner;

public class WuziA  {
    class Dir {
        int x;
        int y;

        Dir(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
    String run(int[] data, int n) throws Exception {
        return "";
    }

    public void check(InputStream fileIn, OutputStream fileOut) throws Exception {
        Scanner scanner = new Scanner(fileIn);
        int n = scanner.nextInt();
        scanner.nextLine();
        String[] arr = new String[n];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = scanner.nextLine();
        }
        int[] data = new int[n * n];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length(); j++) {
                int index = i * n + j;
                int c = arr[i].charAt(j);
                if (c == 'w') {
                    data[index] = 1;
                } else if (c == 'b') {
                    data[index] = 2;
                }
            }
        }
        String str = run(data, n);
        fileOut.write(str.getBytes());
    }
    public static void main(String[] args){
        try {
            WuziA wf=new WuziA();
            wf.check(System.in,System.out);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
