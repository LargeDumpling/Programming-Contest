
#include <iostream>
#include <string>
using namespace std;



 class Dir {
    public:
    int x;
    int y;
    Dir(int x, int y) {
        this->x = x;
        this->y = y;
    }
    Dir(){

    }
};
void run(int* data, int n) {
    
}

int main(int argc, char *argv[]){
    int n ;
    cin>>n;
    string line;
    getline(cin, line);
    string* arr = new string[n];
    for (int i = 0; i < n; i++) {
        getline(cin, arr[i]);
    }
    int* data = new int[n * n];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < arr[i].length(); j++) {
            int index = i * n + j;
            int c = arr[i][j];
            if (c == 'w') {
                data[index] = 1;
            } else if (c == 'b') {
                data[index] = 2;
            }else{
                data[index]=0;
            }
        }
    }
    run(data, n);
}

















