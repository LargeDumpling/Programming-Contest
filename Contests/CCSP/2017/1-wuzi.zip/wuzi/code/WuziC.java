import java.io.*;
import java.util.Scanner;

public class WuziC  {
    class Dir {
        int x;
        int y;

        Dir(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
    String run(int[] data, int n) throws Exception {
        StringBuilder sb = new StringBuilder();
        Dir[] dirs = new Dir[4];
        dirs[0] = new Dir(1, 0);
        dirs[1] = new Dir(0, 1);
        dirs[2] = new Dir(1, -1);
        dirs[3] = new Dir(1, 1);
        for (int i = 0; i < n * n; i++) {
            int x = i % n;
            int y = i / n;
            int index = y * n + x;
            if (data[index] == 0) {
                //表示对五子连珠数量的影响
                int re = 0;

                for (int j = 0; j < dirs.length; j++) {
                    Dir dir = dirs[j];
                    int oldv = 0;
                    int newv = 0;
                    int l = 0;
                    int r = 0;
                    int px = x;
                    int py = y;
                    while (px + dir.x < n && px + dir.x >= 0 && py + dir.y >= 0 && py + dir.y < n) {
                        px += dir.x;
                        py += dir.y;
                        if (data[py * n + px] == 1) {
                            l++;
                        } else {
                            break;
                        }
                    }
                    px = x;
                    py = y;
                    while (px - dir.x < n && px - dir.x >= 0 && py - dir.y >= 0 && py - dir.y < n) {
                        px -= dir.x;
                        py -= dir.y;
                        if (data[py * n + px] == 1) {
                            r++;
                        } else {
                            break;
                        }
                    }
                    if (l >= 5) {
                        oldv++;
                    }
                    if (r >= 5) {
                        oldv++;
                    }
                    if (l + r >= 4) {
                        newv = 1;
                    }
                    re +=newv;
                }
                if (re>0) {
                    sb.append(String.format("%d %d\n", x, y));
                }
            }
        }
        return sb.toString();
    }

    public void check(InputStream fileIn, OutputStream fileOut) throws Exception {
        Scanner scanner = new Scanner(fileIn);
        int n = scanner.nextInt();
        scanner.nextLine();
        String[] arr = new String[n];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = scanner.nextLine();
        }
        int[] data = new int[n * n];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length(); j++) {
                int index = i * n + j;
                int c = arr[i].charAt(j);
                if (c == 'w') {
                    data[index] = 1;
                } else if (c == 'b') {
                    data[index] = 2;
                }
            }
        }
        String str = run(data, n);
        fileOut.write(str.getBytes());
    }
    public static void main(String[] args){
        try {
            WuziC wf=new WuziC();
            wf.check(System.in,System.out);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
