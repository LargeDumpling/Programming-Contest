
#include <iostream>
#include <string>
using namespace std;



 class Dir {
    public:
    int x;
    int y;
    Dir(int x, int y) {
        this->x = x;
        this->y = y;
    }
    Dir(){

    }
};
void run(int* data, int n) {
    Dir dirs[2];
    dirs[0] = Dir(1, 0);
    dirs[1] = Dir(0, 1);
    for (int i = 0; i < n * n; i++) {
        int x = i % n;
        int y = i / n;
        int index = y * n + x;

        if (data[index] == 0) {
            int re=0;
            bool valid = false;
            for (int j = 0; j < 4; j++) {
                int newv=0;
                int oldv=0;
                Dir dir = dirs[j];
                int l = 0;
                int r = 0;
                int px = x;
                int py = y;
                while (px + dir.x < n && px + dir.x >= 0 && py + dir.y >= 0 && py + dir.y < n) {
                    px += dir.x;
                    py += dir.y;
                    if (data[py * n + px] == 1) {
                        l++;
                    } else {
                        break;
                    }
                }
                px = x;
                py = y;
                while (px - dir.x < n && px - dir.x >= 0 && py - dir.y >= 0 && py - dir.y < n) {
                    px -= dir.x;
                    py -= dir.y;
                    if (data[py * n + px] == 1) {
                        r++;
                    } else {
                        break;
                    }
                }
                if (l >= 5) {
                    oldv++;
                }
                if (r >= 5) {
                    oldv++;
                }
                if (l + r >= 4) {
                    newv = 1;
                }
                re += newv;
            }
            if (re>0) {
                cout<<x<<" "<<y<<"\n";
            }
        }
    }
}

int main(int argc, char *argv[]){
    int n ;
    cin>>n;
    string line;
    getline(cin, line);
    string* arr = new string[n];
    for (int i = 0; i < n; i++) {
        getline(cin, arr[i]);
    }
    int* data = new int[n * n];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < arr[i].length(); j++) {
            int index = i * n + j;
            int c = arr[i][j];
            if (c == 'w') {
                data[index] = 1;
            } else if (c == 'b') {
                data[index] = 2;
            }else{
                data[index]=0;
            }
        }
    }
    run(data, n);
}

















