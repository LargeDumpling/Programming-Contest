import json
import re
import sys
import os

inf = 1e100

def printf(*arg, **argw):
	print(*arg, **argw)
	sys.stdout.flush()

class InputException(Exception):
	def __init__(self, value = ''):
		self.value = value
	def __str__(self):
		return '[E]At line %d : %s' % (line, repr(self.value))
		
def get_strs(f, num = None, split = ' '):
	global line
	line += 1
	items = f.readline().strip('\n').split(split)
	if num != None and len(items) != num:
		raise InputException('Must contain %d items, but %d get.%s' % (
			num,
			len(items),
			' May contain extra spaces at the end of the line.' if len(items) > num else ''
		))
	return items

def get_ints(f, num = None, split = ' '):
	items = get_strs(f, num, split)
	try:
		return list(map(int, items))
	except Exception as e:
		raise InputException(e)
		
def get_eof(f):
	global line
	line += 1
	extra = f.readline()
	if extra:
		raise InputException('Must get EOF but "%s" get.' % extra)

def check_(lef, rig, name_lef = None, name_rig = None, tp = 'eq'):
	if not lef.__getattribute__('__%s__' % tp)(rig):
		raise InputException('%s must equal to %s, but %s and %s get.' % (
			('Variable `' + name_lef + '`') if name_lef else str(lef),
			('Variable `' + name_rig + '`') if name_rig else str(rig),
			str(lef),
			str(rig)
		))
		
def check_in(item, in_set, name = None):
	if item not in in_set:
		raise InputException('Variable `%s` must in %s, but %s get.' % (' "' + name + '"' if name else '', repr(in_set), repr(item)))
		
def check_re(item, r, name = None):
	if not r.match(item):
		raise InputException('Variable `%s` must match "%s", but %s get.' % (' "' + name + '"' if name else '', r.pattern, repr(item)))
		
def check_true(result, info = None):
	if not result:
		raise InputException(info if info else 'Expression must be True but False get.')

def is_prime(num):
	for i in range(2, num):
		if i * i > num:
			return True
		if num % i == 0:
			return False
	return True

def shorter(dist, n):
	for k in range(n):
		for i in range(n):
			for j in range(n):
				if dist[i][j] > dist[i][k] + dist[k][j]:
					return (i, j, k)
	return None

tps = [
	(0, 0, 0),
	(1, 0, 0),
	(1, 1, 0),
	(1, 1, 1)
]

def check_case(f, gargs = None, largs = None):
	first_self_loop = True
	first_repeat_edge = True
	try:
		n, = get_ints(f, 1)
		check_in(n, range(1, gargs['n'] + 1))
		board = []
		for i in range(n):
			line, = get_strs(f, 1)
			check_(len(line), n, 'line length', 'n')
			for j, c in enumerate(line):
				check_in(c, {'*', 'b', 'w'}, j)
			board.append(line)
		get_eof(f)
		with open('in.tmp', 'w') as fo:
			fo.write('%d\n' % n)
			for line in board:
				fo.write('%s\n' % line)
		if largs:
			os.system('test.exe < in.tmp > out.tmp 2> prop.tmp')
			props = map(int, open('prop.tmp').read().strip().split())
			check_(props, tps[largs['type']], 'props')
		printf('Check succeeded.')
	except Exception as e:
		printf(e)
		printf('Check failed.')

if __name__ == '__main__':
	conf = json.loads(open('../conf.json', 'rb').read().decode('utf-8'))
	os.system('g++ test.cpp -o test.exe -Wall -O2 -std=c++14')
	for tp in ('data', 'samples'):
		for datum in conf[tp]:
			for case in datum['cases']:
				printf('Checking %s %d' % (tp, case))
				try:
					with open('../%s/%d.in' % ('data' if tp == 'data' else 'down', case), 'r') as f:
						line = 0
						check_case(f, conf.get('args', None), datum.get('args', None))
				except Exception as e:
					printf('[E]Can\'t read input file.')
