#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>

const int N = 55;
int n, mark[N][N];
char board[N][N];
bool has_sol;
bool use_slash;
bool has_old;

struct Point{
	int x, y;
	Point(){}
	Point(int _x, int _y):
		x(_x), y(_y){}
	Point operator+(const Point& a)const{
		return Point(x + a.x, y + a.y);
	}
	Point operator-(const Point& a)const{
		return Point(x - a.x, y - a.y);
	}
	Point& operator+=(const Point& a){
		x += a.x;
		y += a.y;
		return *this;
	}
	bool in()const{
		return x >= 0 && y >= 0 && x < n && y < n;
	}
};
const Point dirs[] = {
	Point(0, 1), Point(-1, 0), Point(-1, 1), Point(-1, -1),
	Point(0, -1), Point(1, 0), Point(1, -1), Point(1, 1)
};

int con(const Point&cen, const Point& d){
	Point c = cen;
	for(int i = 1; i < 5; i++){
		c += d;
		if(!c.in() || board[c.x][c.y] != 'w')
			return i - 1;
	}
	return 4;
}

void mark_dir(const Point& cen, int dir, int l){
	//printf("!!\n");
	Point c = cen;
	for(int i = 0; i < l; i++){
		mark[c.x][c.y] |= 1 << dir;
		c += dirs[dir];
	}
}

void brush(){
	for(int x = 0; x < n; x++)
		for(int y = 0; y < n; y++)
			if(board[x][y] == 'w')
				for(int i = 0; i < 4; i++)
					if(con(Point(x, y), dirs[i]) >= 4){
						has_old = true;
						mark_dir(Point(x, y), i, 5);
					}
}

bool check(const Point& c){
	if(board[c.x][c.y] != '*')
		return false;
	int tot = 0, tot2 = 0;
	for(int i = 0; i < 4; i++){
		Point pos = c + dirs[i];
		Point neg = c - dirs[i];
		tot -= bool(mark[pos.x][pos.y] & (1 << i));
		tot -= bool(mark[neg.x][neg.y] & (1 << i));
		tot += bool(con(c, dirs[i]) + con(c, dirs[i | 4]) >= 4);
		if(i == 1)
			tot2 = tot;
	}
	if(tot != tot2)
		use_slash = true;
	return tot > 0;
}

int main(){
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
		scanf(" %s", board[i]);
	brush();
	/*for(int i = 0; i < n; i++){
		for(int j = 0; j < n; j++)
			printf("%d", mark[i][j]);
		printf("\n");
	}*/
	for(int i = 0; i < n; i++)
		for(int j = 0; j < n; j++)
			if(check(Point(i, j))){
				has_sol = true;
				printf("%d %d\n", j, i);
			}
	fprintf(stderr, "%d %d %d\n", int(has_sol), int(use_slash), int(has_old));
	return 0;
}
