g++ part2A.cpp -o part2A
g++ part2B.cpp -o part2B
g++ part2C.cpp -o part2C
echo Subtask A:
./part2A <trick_a1.out
echo
echo Subtask B:
./part2B <trick_a2.out
echo
echo Subtask C:
./part2C <trick_a3.out
echo
rm -rf part2A
rm -rf part2B
rm -rf part2C
