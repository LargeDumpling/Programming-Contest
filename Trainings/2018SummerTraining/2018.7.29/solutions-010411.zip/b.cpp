#include <cstdio>
#include <vector>
#include <cassert>
#include <cmath>
#include <algorithm>
using namespace std;

const int N = 1050;

#define MOD1000000007

#ifdef MOD1000000007
struct mod;
mod* inv;

struct mod {
    static constexpr int MOD = 1000 * 1000 * 1000 + 7;
    mod(int x_) : x(x_) { }
    mod() = default;
    int x = 0;
    inline mod operator *(mod other) const {
        return ((long long)x * other.x) % MOD;
    }
    inline mod& operator *=(mod other) {
        x = ((long long)x * other.x) % MOD;
        return *this;
    }
    inline mod operator +(mod other) const {
        int res = x + other.x;
        if (res >= MOD) {
            res -= MOD;
        }
        return res;
    }
    inline mod& operator +=(mod other) {
        if ((x += other.x) >= MOD) {
            x -= MOD;
        }
        return *this;
    }
    inline mod operator -(mod other) const {
        int res = x - other.x;
        if (res < 0) {
            res += MOD;
        }
        return res;
    }
    inline mod& operator -=(mod other) {
        if ((x -= other.x) < 0) {
            x += MOD;
        }
        return *this;
    }
    inline mod operator /(mod other) const {
        return (*this) * inv[other.x];
    }
    inline mod& operator /=(mod other) {
        return *this *= inv[other.x];
    }
    inline bool operator ==(mod other) const {
        return x == other.x;
    }
    inline mod operator -() const {
        return x != 0 ? MOD - x : 0;
    }
};
typedef mod ld;

inline bool eq(mod a, mod b) {
    return a == b;
}

void init_inv() {
    inv = new mod[N];
    inv[1] = 1;
    for (int i = 2; i < N; i++) {
        inv[i] = (mod::MOD - (long long)mod::MOD / i * inv[mod::MOD % i].x % mod::MOD) % mod::MOD;
    }
}

mod sanitize(int x_) {
    if (x_ < 0) {
        x_ += mod::MOD;
    }
    return mod(x_);
}

#else

typedef long double ld;
const ld eps = 1e-6;
bool eq(ld a, ld b) {
    return fabs(a - b) < eps;
}

#define sanitize(x) (x)

#endif

struct poly {
    vector<ld> C;
    poly() {}
    explicit poly(vector<ld> C_)
        : C(move(C_))
    { }
    static const poly zero;
    int deg() const {
        return (int)C.size() - 1;
    }
    ld operator[](int x) const {
        return (x < 0 || x > deg()) ? ld(0) : C[x];
    }
    ld& operator[](int x) {
        if (x > deg()) {
            C.resize(x + 1);
        }
        return C[x];
    }
    friend poly operator +(const poly& a, const poly& b) {
        vector<ld> c(max(a.deg(), b.deg()) + 1);
        for (int i = 0; i < c.size(); i++) {
            c[i] = a[i] + b[i];
        }
        return poly(c);
    }
    friend poly operator -(const poly& a, const poly& b) {
        vector<ld> c(max(a.deg(), b.deg()) + 1);
        for (int i = 0; i < c.size(); i++) {
            c[i] = a[i] - b[i];
        }
        return poly(c);
    }
    bool isZero() const {
        return C.empty();
    }
    friend poly operator *(const poly& a, const poly& b) {
        if (a.isZero() || b.isZero()) {
            return zero;
        }
        vector<ld> c(1 + a.deg() + b.deg());
        for (int i = 0; i <= a.deg(); i++) {
            for (int j = 0; j <= b.deg(); j++) {
                c[i + j] += a[i] * b[j];
            }
        }
        return poly(c);
    }
    poly derivative() const {
        if (isZero()) {
            return zero;
        }
        vector<ld> res(deg());
        for (int i = 0; i < deg(); i++) {
            res[i] = C[i + 1] * (i + 1);
        }
        return poly(res);
    }
    poly primitive() const {
        if (isZero()) {
            return zero;
        }
        vector<ld> res(2 + deg());
        for (int i = 1; i <= 1 + deg(); i++) {
            res[i] = C[i - 1] / i;
        }
        return poly(res);
    }
    ld operator()(ld x) const {
        ld res = 0;
        for (int i = deg(); i >= 0; i--) {
            res = res * x + C[i];
        }
        return res;
    }
    // Expand P(x+t).
    poly shift(ld t) const {
        poly res;
        res[deg()];
        vector<ld> binomial(deg() + 1, 0);
        binomial[0] = 1;
        for (int i = 0; i <= deg(); i++) {
            ld cur = 1;
            for (int j = i; j >= 0; j--) {
                res[j] += C[i] * binomial[j] * cur;
                cur *= t;
            }
            if (i == deg()) {
                break;
            }
            for (int j = i + 1; j > 0; j--) {
                binomial[j] += binomial[j - 1];
            }
        }
        return res;
    }
};

const poly poly::zero;

struct ppf {
    vector<poly> P;
    explicit ppf(vector<poly> P_)
        : P(std::move(P_))
    { }
    int len() const {
        return (int)P.size();
    }
    void validate_density() const {
        assert(len() >= 1);
        assert(eq(integral(), 1));
    }
    static const ppf zero;
    ld operator ()(int x) const {
        int i = x;
        if (i >= len()) {
            i = len() - 1;
        }
        if (i < 0) {
            i = 0;
        }
        return P[i](x);
    }
    const poly& operator[](int i) const {
        return (i < len() && i >= 0) ? P[i] : poly::zero;
    }
    friend ppf operator *(const ppf& a, const poly& b) {
        vector<poly> res(a.len());
        for (int i = 0; i < a.len(); i++) {
            res[i] = a[i] * b;
        }
        return ppf(std::move(res));
    }
    friend ppf operator *(const ppf& a, const ppf& b) {
        vector<poly> res(min(a.len(), b.len()));
        for (int i = 0; i < (int)res.size(); i++) {
            res[i] = a[i] * b[i];
        }
        return ppf(std::move(res));
    }
    ppf primitive() const {
        vector<poly> res;
        for (int i = 0; i < len(); i++) {
            res.emplace_back(P[i].primitive());
            res.back()[0] += (i ? res[i - 1](i) : 0) - res[i](i);
        }
        return ppf(std::move(res));
    }
    ppf derivative() const {
        vector<poly> res;
        for (int i = 0; i < len(); i++) {
            res.emplace_back(P[i].derivative());
        }
        return ppf(std::move(res));
    }
    // Expand P(x + t).
    ppf shift(int t) const {
        vector<poly> res;
        for (int i = 0; i + t < len(); i++) {
            res.emplace_back(i + t >= 0 ? P[i + t].shift(sanitize(t)) : poly::zero);
        }
        return ppf(std::move(res));
    }
    // Integrate from 0 to len().
    ld integral() const {
        ld sum = 0;
        return len() ? primitive()(len()) : 0;
    }
};
const ppf ppf::zero({});

ppf density_max(const ppf& a, const ppf& b) {
    vector<poly> P;
    auto ap = a.primitive();
    auto bp = b.primitive();
    for (int i = 0; i < std::max(a.len(), b.len()); i++) {
        auto u = b[i];
        if (i < ap.len()) {
            u = u * ap[i];
        }
        auto v = a[i];
        if (i < bp.len()) {
            v = v * bp[i];
        }
        P.emplace_back(u + v);
    }
    return ppf(std::move(P));
}


ppf density_add_uniform(const ppf& a) {
    if (a.len() == 0) {
        return ppf({poly({1})});
    }
    vector<poly> P(a.len() + 1);
    ppf ap = a.primitive();
    ppf ap1 = ap.shift(-1);
    for (int i = 1; i < a.len(); i++) {
        P[i] = ap[i] - ap1[i];
    }
    P[0] = ap[0];
    P[a.len()] = poly({1}) - ap1[a.len()];
    return ppf(std::move(P));
}

// a(s) -> int_{s,s+1} a(t) dt.
ppf integrate_unit(const ppf& a) {
    vector<poly> P(a.len());
    ppf ap = a.primitive();
    ppf ap1 = ap.shift(1);
    for (int i = 0; i < a.len(); i++) {
        P[i] = ap1[i] - ap[i];
    }
    if (a.len()) {
        P[a.len() - 1] = poly({ap(a.len())}) - ap[a.len() - 1];
    }
    return ppf(std::move(P));
}

ld expected_diameter_sub(const ppf& a, const ppf& b) {
    ppf ib = integrate_unit(b);
    ppf bs = b * poly({0, 1});
    ppf ibs = integrate_unit(bs);
    ppf bss = bs * poly({0, 1});
    ppf ibss = integrate_unit(bss);
    ppf at1 = a * poly({1, 1});
    ppf at = a * poly({0, 1});
    ppf att1 = at * poly({1, 1});
    ppf att = at * poly({0, 1});
    ld iatt1ib = (att1 * ib).integral();
    ld iatibs = (at * ibs).integral();
    ld iat1ibs = (at1 * ibs).integral();
    ld iaibss = (a * ibss).integral();
    ld iattib = (att * ib).integral();
    ld iaib = (a * ib).integral();
    ld ea = iatt1ib - iatibs;
    ld eb = iat1ibs - iaibss;
    ld ec = -iattib / 2 - iaibss / 2 + iatibs + iaib / 2;
    return ea + eb + ec;
}

ld expected_diameter_oneway(const ppf& b) {
    // TODO
    ppf ib = integrate_unit(b);
    ppf bs = b * poly({0, 1});
    ppf ibs = integrate_unit(bs);
    ppf bss = bs * poly({0, 1});
    ppf ibss = integrate_unit(bss);
    ld ans1 = ibs(0) - ibss(0) - ibss(0) / 2 + ib(0) / 2;
    return ans1;
}

ld expected_diameter(const ppf& a, const ppf& b) {
    if (a.len() == 0 && b.len() == 0) {
        return ld(1) / 2;
    } else if (a.len() == 0 && b.len() != 0) {
        return expected_diameter_oneway(b);
    } else if (a.len() != 0 && b.len() == 0) {
        return expected_diameter_oneway(a);
    } else {
        auto x = expected_diameter_sub(a, b);
        auto y = expected_diameter_sub(b, a);
        return x + y;
    }
}

void test() {
    ppf a({poly({1})});
    ppf b({poly({1})});
    ppf l({poly({ld(1) / 2}), poly({ld(1) / 2})});
    ppf m = l;
    l.validate_density();
    m.validate_density();
    auto n = density_max(l, m);
    n.validate_density();
    auto o = density_max(l, a);
    o.validate_density();
    auto c = density_max(a, b);
    c.validate_density();
    auto d = density_add_uniform(a);
    d.validate_density();
    auto e = density_add_uniform(d);
    e.validate_density();
    auto g = density_max(e, c);
    g.validate_density();
    auto h = density_add_uniform(g);
    h.validate_density();
    auto i = density_max(g, g);
    i.validate_density();
    auto j = density_add_uniform(i);
    j.validate_density();
    auto k = density_max(j, h);
    k.validate_density();
    ld p = expected_diameter(ppf::zero, ppf::zero);
    assert(eq(p, ld(1) / 2));
    ld q = expected_diameter(ppf::zero, a);
    assert(eq(p, ld(1) / 2));
    ld r = expected_diameter(ppf(a), ppf(a));
    ld s = expected_diameter(ppf::zero, ppf(d));
    assert(r + s + s == ld(3) / 2);
    ld w = expected_diameter(c, ppf::zero);
    assert(eq(w, ld(5) / 12));
    const int v = 10;
    vector<ppf> t(v, ppf::zero);
    for (int i = 1; i < (int)t.size(); i++) {
        t[i] = density_add_uniform(t[i - 1]);
    }
    ld u = 0;
    for (int i = 0; i <= v - 1; i++) {
        u += expected_diameter(t[i], t[v - 1 - i]);
    }
    ld z0 = expected_diameter(t[0], t[3]);
    ld z1 = expected_diameter(t[1], t[2]);
    assert(eq(z0 + z0 + z1 + z1, 2));
    assert(eq(u, ld(v) / 2));
    ld x = ld(4) * expected_diameter(ppf::zero, density_max(a, density_max(a, a)));
    assert(eq(x, ld(7) / 5));
    ld y1 = expected_diameter(l, a);
    ld y2 = expected_diameter(ppf::zero, density_add_uniform(l));
}

vector<ppf> H;
vector<vector<int>> E;
vector<vector<ppf>> T;

void DFS(int x, int p = -1) {
    if (p != -1) {
        E[x].erase(find(E[x].begin(), E[x].end(), p));
    }
    H[x] = ppf::zero;
    for (int y : E[x]) {
        DFS(y, x);
        T[x].emplace_back(density_add_uniform(H[y]));
        H[x] = density_max(H[x], T[x].back());
    }
}

ld DFS2(int x, const ppf& top) {
    ld ans = 0;
    vector<ppf> pref(E[x].size() + 1, ppf::zero), suff(E[x].size() + 1, ppf::zero);
    for (int i = 0; i < (int)E[x].size(); i++) {
        pref[i + 1] = density_max(pref[i], T[x][i]);
    }
    for (int i = (int)E[x].size() - 1; i >= 0; i--) {
        suff[i] = density_max(suff[i + 1], T[x][i]);
    }
    for (int i = 0; i < (int)E[x].size(); i++) {
        int y = E[x][i];
        auto ntop = density_max(top, density_max(pref[i], suff[i + 1]));
        ans += expected_diameter(H[y], ntop);
        ans += DFS2(y, density_add_uniform(ntop));
    }
    return ans;
}

int main() {
    #ifdef MOD1000000007
        init_inv();
    #endif
    test();
    int n;
    scanf("%d", &n);
    E.resize(n);
    H.resize(n, ppf::zero);
    T.resize(n);
    for (int i = 0; i < n - 1; i++) {
        int a, b;
        scanf("%d %d", &a, &b);
        --a, --b;
        E[a].push_back(b);
        E[b].push_back(a);
    }
    DFS(1);
    ld ans = DFS2(1, ppf::zero);
    #ifdef MOD1000000007
        printf("%d\n", ans.x);
    #else
        printf("%.10Lf\n", ans);
    #endif
}
