#include <bits/stdc++.h>
using namespace std;
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define fore(i, b, e) for (int i = (int)(b); i <= (int)(e); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define pb push_back
#define fi first
#define se second
#define all(x) (x).begin(), (x).end()
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long long i64;
typedef unsigned long long u64;
typedef long double ld;
typedef long long ll;

const int maxn = 1000500;

int fen[maxn];
void fadd(int i, int x) {
    for (; i < maxn; i |= (i+1))
        fen[i] += x;
}
int fget(int i) {
    int s = 0;
    for (; i >= 0; i = (i&(i+1))-1)
        s += fen[i];
    return s;
}
// min i: fget(i) >= x
int frev(int x) {
    int res = 0;
    int s = 0;
    for (int step = 1<<20; step >= 1; step /= 2) {
        int i = res + step - 1;
        if (i < maxn && s + fen[i] < x) {
            s += fen[i];
            res += step;
        }
    }
    return res;
}

int n;
int nc;
int sz; // number of groups in line at the moment
int len; // number of people in line at the moment
vi a[maxn];
int pres[maxn];
int res[maxn];

unordered_map<int, int> _id;
int getid(int x) {
    if (!_id.count(x)) {
        int t = _id.size();
        return _id[x] = t;
    }
    return _id[x];
}

int add(int c, int mx) {
    c = getid(c);
    // cerr << endl;
    // cerr << "c = " << c << ", mx = " << mx << ", minpos = " << len-mx << endl;
    if (c == nc) {
        a[nc] = {sz};
        ++nc;
        fadd(sz, 1);
        ++sz;
        return len;
    }
    int minpos = len - mx;
    int mingroup = frev(minpos);
    // cerr << "mingroup = " << mingroup << endl;
    auto it = lower_bound(all(a[c]), mingroup);
    if (it == a[c].end()) {
        a[c].push_back(sz);
        fadd(sz, 1);
        ++sz;
        return len;
    }

    int gr = *it;
    // cerr << "add to group " << gr << endl;
    int before = fget(gr-1);
    fadd(gr, 1);
    return max(minpos, before);
}

void restore() {
    memset(fen, 0, sizeof(fen));
    forn(i, n) fadd(i, 1);
    ford(i, n) {
        int pos = frev(pres[i] + 1);
        res[pos] = i;
        fadd(pos, -1);
    }
}

void solve() {
    cin >> n;
    forn(i, n) {
        int c, mx;
        cin >> c >> mx;
        int pos = add(c, mx);
        // cerr << "put to " << pos << endl;
        pres[i] = pos;
        ++len;

        // forn(i, sz) cerr << fget(i) - fget(i-1) << " "; cerr << endl;
    }
    restore();
    forn(i, n) cout << res[i] + 1 << " ";
    cout << endl;
}

int main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif

    ios::sync_with_stdio(false);

    solve();

#ifdef LOCAL
    cerr << "Time elapsed: " << clock() / 1000 << " ms" << endl;
#endif
    return 0;
}
