#include <bits/stdc++.h>
using namespace std;
#define sz(v) ((int)((v).size()))
#define all(v) (v).begin(),(v).end()
typedef long long ll;
typedef pair<int,int> ii;

class Updater {
public:
    virtual void update(int& a, int b) = 0;
};

class MinUpdater : public Updater {
public:
    void update(int &a, int b) {
        a = min(a, b);
    }
} minUpdater;

class MaxUpdater : public Updater {
public:
    void update(int &a, int b) {
        a = max(a, b);
    }
} maxUpdater;

int n, s;
vector<int> order;
vector<int> a;
vector<int> b;
vector<vector<int>> va;
vector<vector<int>> vb;
vector<char> usedA;
vector<char> usedB;

int brute(int pos, int curAns) {
    if (pos == sz(order)) {
        return curAns;
    }
    int player = order[pos];

    Updater* updater;
    int bestAns;
    int mult;
    if (player < n) {
        updater = &maxUpdater;
        bestAns = -int(1e9);
        mult = 1;
    } else {
        updater = &minUpdater;
        bestAns = int(1e9);
        mult = -1;
    }

    if (sz(va[player]) < s) {
        for (int i = 0; i < sz(a); i++) {
            if (!usedA[i]) {
                usedA[i] = true;
                va[player].push_back(i);
                updater->update(bestAns, brute(pos + 1, curAns + mult * a[i]));
                va[player].pop_back();
                usedA[i] = false;
                break;
            }
        }
    }
    if (sz(vb[player]) < 1) {
        for (int i = 0; i < sz(b); i++) {
            if (!usedB[i]) {
                usedB[i] = true;
                vb[player].push_back(i);
                updater->update(bestAns, brute(pos + 1, curAns + mult * b[i]));
                vb[player].pop_back();
                usedB[i] = false;
                break;
            }
        }
    }

    return bestAns;
}

int main() {
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    cin >> n >> s;
    order.resize((s + 1) * 2 * n);
    for (int i = 0; i < sz(order); i++) {
        cin >> order[i];
        order[i]--;
    }

    int szA;
    cin >> szA;
    a.resize(szA);
    for (int i = 0; i < szA; i++) {
        cin >> a[i];
    }
    sort(all(a));
    reverse(all(a));

    int szB;
    cin >> szB;
    b.resize(szB);
    for (int i = 0; i < szB; i++) {
        cin >> b[i];
    }
    sort(all(b));
    reverse(all(b));

    usedA.resize(sz(a));
    usedB.resize(sz(b));
    va.resize(2 * n);
    vb.resize(2 * n);
    cout << brute(0, 0) << endl;
}

