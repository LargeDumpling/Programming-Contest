#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <string>
#include <iostream>
#include <vector>
#include <utility>
#include <cstdint>

struct FFT {
    const int STEPS = 20;
    int p;
    int eps;
    std::vector<int> epsPow;
    std::vector<int> epsInvPow;
    std::vector<int> inv;

    int mult(int x, int y) {
        return (int64_t(x) * y) % p;
    }

    void init() {
        for (p = (1 << 29) + 1; ; p += 1 << STEPS) {
            bool good = true;
            for (int j = 2; j * j < p; j++) {
                if (p % j == 0) {
                    good = false;
                    break;
                }
            }
            if (good) break;
        }
        for (eps = 2; ; eps++) {
            bool good = true;
            int cur = eps;
            for (int j = 0; j < STEPS; j++) {
                if (cur == 1) {
                    good = false;
                }
                cur = mult(cur, cur);
            }
            if (good && cur == 1) break;
        }
        epsPow.resize(1 << STEPS);
        epsInvPow.resize(1 << STEPS);
        int cur = 1;
        for (size_t i = 0; i < epsPow.size(); i++) {
            epsPow[i] = cur;
            cur = mult(cur, eps);
        }
        epsInvPow[0] = 1;
        for (size_t i = 1; i < epsInvPow.size(); i++) {
            epsInvPow[i] = epsPow[epsPow.size() - i];
        }
        inv.resize(1 << STEPS);
        for (size_t i = 1; i < inv.size(); i++) {
            inv[i] = (inv[i / 2] >> 1) + (((int)i & 1) << (STEPS - 1));
        }
    }

  FFT() {
        init();
  }

    void furier(std::vector<int>& input, std::vector<int>& epsPow, std::vector<int>& output, int order) {
        int n = 1 << order;
        int invShift = STEPS - order;
        for (int i = 0; i < n; i++) {
            output[i] = input[inv[i] >> invShift];
        }
        for (int block = 0; block < order; block++) {
            int step = 1 << block;
            int step2 = 1 << (block + 1);
            int shiftEps = STEPS - block - 1;
            for (int start = 0; start < n; start += step2) {
                for (int i = 0; i < step; i++) {
                    int x0 = output[start + i];
                    int x1 = output[start + step + i];
                    int x1Mult = mult(x1, epsPow[i << shiftEps]);
                    output[start + i] = (x0 + x1Mult) % p;
                    output[start + step + i] = (x0 - x1Mult + p) % p;
                }
            }
        }
    }

    void multiply(std::vector<int>& input1, std::vector<int>& input2, std::vector<int>& output) {
        size_t i1, i2;
        for (i1 = input1.size(); i1-- > 0;) {
            if (input1[i1] != 0) break;
        }
        for (i2 = input2.size(); i2-- > 0;) {
            if (input2[i2] != 0) break;
        }
        int sum = i1 + i2;
        int order = 0;
        while ((1 << order) <= sum) order++;
        input1.resize(1 << order);
        input2.resize(1 << order);
        output.resize(1 << order);
        std::vector<int> out1(input1.size());
        std::vector<int> out2(input2.size());
        furier(input1, epsPow, out1, order);
        furier(input2, epsPow, out2, order);
        for (size_t i = 0; i < out1.size(); i++) {
            out1[i] = mult(out1[i], out2[i]);
        }
        furier(out1, epsInvPow, output, order);
        uint32_t inv = 1;
        for (int i = 0; i < order; i++) {
            if (inv & 1) {
                inv += p;
            }
            inv /= 2;
        }
        for (size_t i = 0; i < output.size(); i++) {
            output[i] = mult(output[i], inv);
        }
    }
};

void multShort(std::vector<int>& x, int m) {
    int c = 0;
    for (int i = 0; i < x.size(); i++) {
        c += x[i] * m;
        x[i] = c % 10;
        c /= 10;
    }
    while (c > 0) {
        x.push_back(c % 10);
        c /= 10;
    }
}

void add(std::vector<int>& x, std::vector<int>& y) {
    if (x.size() < y.size()) {
        x.resize(y.size());
    }
    int c = 0;
    for (int i = 0; i < x.size(); i++) {
        c += x[i] + ((i < y.size()) ? y[i] : 0);
        x[i] = c % 10;
        c /= 10;
    }
    while (c > 0) {
        x.push_back(c % 10);
        c /= 10;
    }
}

void normalize(std::vector<int>& x) {
    while (x.size() > 1 && x.back() == 0) {
        x.resize(x.size() - 1);
    }
}

void printNum(std::vector<int>& num) {
    for (int i = 0; i < num.size(); i++) {
        std::cout << num[i] << " ";
    }
    std::cout << "\n";
}

std::vector<int> divideOne(const std::vector<int>& num, int k) {
    // std::cout << "divide by " << k << "\n";
    std::vector<int> res(num.size());
    std::vector<int> cur(k + 6);
    int shift = (num.size() / k) * k;
    while (shift >= 0) {
        int c = 0;
        for (int i = 0; i < k; i++) {
            c += cur[i] + (i + shift < num.size() ? num[i + shift] : 0);
            cur[i] = c % 10;
            c /= 10;
        }
        for (int i = k; i < cur.size(); i++) {
            c += cur[i];
            cur[i] = c % 10;
            c /= 10;
        }
        if (shift == 0) break;
        // std::cout << "shift " << shift << "\n";
        // std::cout << "cur ";
        // printNum(cur);
        for (int i = 0; i < k; i++) {
            res[shift - k + i] = cur[i];
        }
        for (int i = k; i < cur.size(); i++) {
            if (cur[i] != 0) {
                res[shift - k + i] += cur[i];
            }
        }
        shift -= k;
        // std::cout << "res ";
        // printNum(res);
    }
    // std::cout << "final\n";
    // std::cout << "cur ";
    // printNum(cur);
    while (true) {
        bool changed = false;
        for (int i = k; i < cur.size(); i++) {
            res[i - k] += cur[i];
            if (cur[i]) changed = true;
            cur[i - k] += cur[i];
            cur[i] = 0;
        }
        if (!changed) break;
        int c = 0;
        for (int i = 0; i < cur.size(); i++) {
            c += cur[i];
            cur[i] = c % 10;
            c /= 10;
        }
    }
    if (std::count(cur.begin(), cur.begin() + k, 9) == k) {
        res[0]++;
    }
    int c = 0;
    for (int i = 0; i < res.size(); i++) {
        c += res[i];
        res[i] = c % 10;
        c /= 10;
    }
    normalize(res);
    // std::cout << "final\n";
    // std::cout << "res ";
    // printNum(res);
    return res;
}

void run(std::istream &in, std::ostream &out) {
    int L;
    uint32_t S;
    in >> L >> S;
    std::vector<int> num(L);
    for (int i = L - 1; i >= 0; i--) {
        num[i] = (S / 1024) % 10;
        S = 747796405 * S - 1403630843;
    }
    multShort(num, 9);
    //printNum(num);
    std::vector<int> ans(1);
    for (int k = 2; k <= num.size() && k <= 12; k++) {
        std::vector<int> divK = divideOne(num, k);
        add(ans, divK);
    }
    std::vector<bool> good(num.size() + 1);
    int addFract = 0;
    uint64_t div = 1000000000000LL; // 10^12
    for (int k = 13; k <= num.size(); k++) {
        uint64_t sum = 0;
        int up = 0;
        for (int i = k - 12; i < num.size(); i += k) {
            up++;
            uint64_t cur = 0;
            for (int j = std::min<int>(12, num.size() - i) - 1; j >= 0; j--) {
                cur = cur * 10 + num[i + j];
            }
            sum += cur;
        }
        int d = sum / div;
        sum %= div;
        if (sum + (d + 9) / 10 + up + 1 >= div) {
            good[k] = false;
            std::vector<int> divK = divideOne(num, k);
            add(ans, divK);
        } else {
            good[k] = true;
            addFract += d;
        }
    }
    //printNum(ans);
    //std::cout << "fract = " << addFract << std::endl;
    std::vector<int> fract{addFract};
    add(ans, fract);
    std::reverse(num.begin(), num.end());
    std::vector<int> shifts(num.size());
    for (int k = 13; k < num.size(); k++) {
        if (good[k]) {
            for (int i = k; i < num.size(); i += k) {
                shifts[i]++;
            }
        }
    }
    FFT fft;
    std::vector<int> mainPart;
    int numSize = num.size();
    //printNum(num);
    //printNum(shifts);
    fft.multiply(num, shifts, mainPart);
    mainPart.resize(numSize);
    //printNum(mainPart);
    std::reverse(mainPart.begin(), mainPart.end());
    add(ans, mainPart);
    normalize(ans);
    for (int i = ans.size() - 1; i >= 0; i--) {
        out << ans[i];
    }
    out << "\n";
}

int main() {
    std::cin.sync_with_stdio(false);
    std::cin.tie(nullptr);
    run(std::cin, std::cout);
    return 0;
}