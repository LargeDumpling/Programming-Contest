#include <cstdio>
#include <cassert>
using namespace std;

const int N = 100500;

const int MOD = 1000 * 1000 * 1000 + 7;
typedef long long llong;

inline int mul(int a, int b) {
    return ((llong)a * b) % MOD;
}

inline int add(int a, int b) {
    if ((a += b) >= MOD) {
        a -= MOD;
    }
    if (a < 0) {
        a += MOD;
    }
    return a;
}

inline int sub(int a, int b) {
    if ((a -= b) < 0) {
        a += MOD;
    }
    if (a >= MOD) {
        a -= MOD;
    }
    return a;
}

inline int powmod(int x, int y) {
    int res = 1;
    while (y > 0) {
        if (y & 1)
            res = mul(res, x);
        x = mul(x, x);
        y >>= 1;
    }
    return res;
}

inline int inv(int x) {
    return powmod(x, MOD - 2);
}

int X[N], Y[N];
int K[N];

inline int div2(int a) {
    return (a & 1) ? (a + MOD) >> 1 : a >> 1;
}

int main(int arg, char* argv[]) {
    int n;
    scanf("%d", &n);
    for (int i = 0; i <= n; i++) {
        scanf("%d %d", &X[i], &Y[i]);
        if (i) {
            assert(X[i] > X[i - 1]);
        }
    }
    for (int i = 0; i < n; i++) {
        int dy = sub(Y[i + 1], Y[i]);
        assert(0 <= dy && dy < MOD);
        int dx = sub(X[i + 1], X[i]);
        assert(0 <= dx && dx < MOD);
        K[i] = mul(dy, inv(dx));
    }
    if (add(K[0], K[n - 1]) != 0) {
        puts("No");
        return 0;
    }
    int expected = add(Y[0], 0);
    int actual = 0;
    for (int i = 1; i < n; i++) {
        int a = div2(sub(K[i], K[i - 1]));
        actual = add(actual, mul(a, X[i] - X[0]));
    }
    if (expected == actual) {
        puts("Yes");
    } else {
        puts("No");
    }
}
