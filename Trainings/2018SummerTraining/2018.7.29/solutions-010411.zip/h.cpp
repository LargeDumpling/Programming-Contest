#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <iostream>
#include <vector>
#include <map>

using namespace std;

long long GetMaxLen(const vector<int>& sketch, int maxVal) {
  long long result = 0;
  int prev = maxVal + 1;
  for (int i = sketch.size() - 1; i >= 0; --i) {
    result += 1LL * (prev - sketch[i]) * (i + 1);
    prev = sketch[i];
  }
  return result;
}

int main() {
  int sketchLen, maxVal;
  long long answerLen;
  cin >> sketchLen >> answerLen >> maxVal;

  vector<int> sketch(sketchLen);

  int last = 1;

  for (int i = 0; i < sketchLen; ++i) {
    cin >> sketch[i];
    sketch[i] = sketch[i] == -1 ? last : sketch[i];
    if (sketch[i] < last) {
      cout << -1 << endl;
      return 0;
    }
    last = sketch[i];
  }

  if (GetMaxLen(sketch, maxVal) < answerLen || answerLen < sketchLen) {
    cout << -1 << endl;
    return 0;
  }

  map<int, int> cntLessOrEqual;
  for (int i = 0; i < sketchLen; ++i) {
    cntLessOrEqual[sketch[i]] = i + 1;
  }

  int lastId = sketchLen - 1;
  int val = maxVal;

  auto showPrefix = [&](int id) {
    for (int i = 0; i <= id; ++i) {
      cout << sketch[i] << ' ';
    }
  };

  auto show = [](int cnt, int val) {
    for (int i = 0; i < cnt; ++i) {
      cout << val << ' ';
    }
  };

  while (lastId >= 0 && lastId < answerLen) {
    int needToPrint = min(lastId + 1LL, answerLen - (lastId + 1));
    int newId = lastId;
    while (newId > 0 && sketch[newId] == val)
      --newId;

    if (needToPrint == 0) {
      showPrefix(lastId);
      break;
    } else if (sketch[lastId] == val && sketch[needToPrint - 1] == val) {
      show(lastId + 1, val);
      answerLen -= (lastId + 1);
      --val;
      lastId = newId;
    } else if (sketch[lastId] == val && sketch[needToPrint - 1] != val) {
      show(needToPrint, val);
      showPrefix(lastId);
      break;
    } else {
      show(needToPrint, val);
      answerLen -= needToPrint;
      --val;
      lastId = newId;
    }
  }

  cout << endl;

  return 0;
}
