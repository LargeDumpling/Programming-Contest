// #define _GLIBCXX_DEBUG
#include <bits/stdc++.h>
using namespace std;
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define fore(i, b, e) for (int i = (int)(b); i <= (int)(e); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define pb push_back
#define fi first
#define se second
#define all(x) (x).begin(), (x).end()
typedef vector<int> vi;
typedef long long i64;
typedef pair<int, i64> pii;
typedef unsigned long long u64;
typedef long double ld;
typedef long long ll;

const int maxn = 1000500;
const i64 inf = 1e18;

template<typename T, typename U>
ostream& operator<<(ostream& out, const pair<T, U>& p) {
    return out << "(" << p.fi << ", " << p.se << ")";
}

struct FlatSet {
    vector<int> a;

    FlatSet() {}
    FlatSet(vector<int> a) : a(std::move(a)) {}

    void add(int x) {
        a.push_back(x);
    }

    void build() {
        sort(all(a));
        a.erase(unique(a.begin(), a.end()), a.end());
    }

    int operator[](int x) const {
        auto it = lower_bound(all(a), x);
        assert(it != a.end() && *it == x);
        return it - a.begin();
    }

    int val(size_t index) const {
        assert(index < a.size());
        return a[index];
    }

    int rlower(int x) const {
        auto it = lower_bound(all(a), x);
        assert(it != a.end());
        return it - a.begin();
    }

    int rupper(int x) const {
        auto it = upper_bound(all(a), x);
        assert(it != a.end());
        return it - a.begin();
    }

    int llower(int x) const {
        auto it = upper_bound(all(a), x);
        assert(it != a.begin());
        return it - a.begin() - 1;
    }

    int lupper(int x) const {
        auto it = lower_bound(all(a), x);
        assert(it != a.begin());
        return it - a.begin() - 1;
    }

    int size() const { return a.size(); }
};

int n;
int a[maxn];

FlatSet fset;

void scan() {
    cin >> n;
    forn(i, n) cin >> a[i];

    forn(i, n) fset.add(a[i]);
    fset.add(-1);
    fset.add(0);
    fset.build();
}

// val2 is stored in mn at the bottom level
struct E {
    int x = 0;
    i64 val = 0;
    pii mn;

    E() {}
    explicit E(int i) : x(fset.val(i)), val(inf), mn(i, inf) {}
    E(E a, E b) {
        if (make_pair(a.mn.se, a.mn.fi) < make_pair(b.mn.se, b.mn.fi)) {
            mn = a.mn;
        } else {
            mn = b.mn;
        }
    }
};

struct M {
    i64 a0 = 0, a1 = 0;

    operator bool() const { return a0 | a1; };

    M() {}
    M(i64 x, i64 y) : a0(x), a1(y) {}

    void apply(E& e) {
        e.val += a0 + a1 * e.x;
        e.mn.se -= a1;
    }

    void apply(M& m) {
        m.a0 += a0;
        m.a1 += a1;
    }
};

struct node {
    int l, r;
    node *L, *R;
    E e;
    M m;

    node(int l, int r) : l(l), r(r) {
        if (l+1 == r) {
            L = R = NULL;
            e = E(l);
        } else {
            int m = (l+r)/2;
            L = new node(l, m);
            R = new node(m, r);
            e = E(L->e, R->e);
        }
    }

    void apply(M m) {
        m.apply(e);
        m.apply(this->m);
    }

    void push() {
        if (m && R) {
            L->apply(m);
            R->apply(m);
        }
        m = M{};
    }

    void update() {
        e = E(L->e, R->e);
    }

    void add(int lq, int rq, M m) {
        if (lq <= l && r <= rq) {
            apply(m);
        } else if (rq <= l || r <= lq) {
        } else {
            push();
            L->add(lq, rq, m);
            R->add(lq, rq, m);
            update();
        }
    }

    void set2(int i, i64 val) {
        assert(l <= i && i < r);
        if (l+1 == r) {
            e.mn.se = val;
        } else {
            push();
            if (i < L->r) L->set2(i, val);
            else R->set2(i, val);
            update();
        }
    }

    i64 get(int i) {
        assert(l <= i && i < r);
        if (l+1 == r) {
            return e.val;
        } else {
            push();
            if (i < L->r) return L->get(i);
            else return R->get(i);
        }
    }

    i64 getrem(int i) {
        assert(l <= i && i < r);
        if (l+1 == r) {
            return e.mn.se;
        } else {
            push();
            if (i < L->r) return L->getrem(i);
            else return R->getrem(i);
        }
    }
};

node *t;

int MM;

set<int> valid;

void pall() {
    cerr << MM << " ";
    for (int x: valid) cerr << "(" << x << " " << t->get(fset[x]) << "; "
        <<t->getrem(fset[x]) << ") ";
    cerr << endl;
}

void updateRem(int x) {
    // cerr << "mark " << x << endl;
    auto xit = valid.find(x);
    assert(xit != valid.begin() && xit != valid.end() && *xit == x);
    int y = *std::prev(xit);

    i64 vx = t->get(fset[x]);
    i64 vy = t->get(fset[y]);

    if (vx >= vy) {
        t->set2(fset[x], 0);
        // cerr << "set1 " << 0 << endl;
    } else {
        int d = x - y;
        t->set2(fset[x], (vy - vx + d - 1) / d);
        // cerr << "set2 " << (vy - vx + d - 1) / d << endl;
    }
}

void tryDelete() {
    // cerr << "try del" << endl;
    while (true) {
        auto kv = t->e.mn;
        // cerr << kv << endl;
        if (kv.se > 0) return;
        assert(kv.se == 0);
        int x = fset.val(kv.fi);
        t->set2(fset[x], inf);
        auto xit = valid.find(x);
        assert(xit != valid.begin() && xit != valid.end() && *xit == x);
        if (std::next(xit) != valid.end()) {
            int y = *std::next(xit);
            valid.erase(xit);
            updateRem(y);
        } else {
            valid.erase(xit);
        }
        // cerr << "delete " << x << endl;
        int pos = fset[x];
        t->add(pos, pos+1, M{inf - t->get(pos), 0});

    }
}

void addval2(int y, i64 val) {
    i64 old = t->get(fset[y]);
    if (old <= val) return;
    int iy = fset[y];
    t->add(iy, iy+1, M{val - old, 0});
    valid.insert(y);
    updateRem(y);
    auto ity = valid.upper_bound(y);
    if (ity != valid.end()) {
        updateRem(*ity);
    }
    tryDelete();
}

void add2(int y) {
    // cerr << "adding " << y << "...\n";
    if (y > MM){
        addval2(MM, t->get(fset[*valid.rbegin()]));
        MM = y;
        return;
    } else {
        int idx = fset[y];
        t->add(0, idx, M{MM - y, 0});
            t->add(idx, fset.size(), M{-y, 1});
            int prv = *std::prev(valid.lower_bound(y));
        if (prv != -1) {
            assert(fset[prv] < idx);
            addval2(y, t->get(fset[prv]) - (MM - y));
        }

        auto ity = valid.lower_bound(y);
        if (ity != valid.end()) {
            if (*ity == y) {
                if (std::next(ity) != valid.end()) updateRem(*std::next(ity));
                updateRem(y);
            } else {
                updateRem(*ity);
            }
        }
        tryDelete();
    }
}

void solve2() {
    MM = 0;
    valid.insert(-1);
    valid.insert(0);
    MM = 0;
    t = new node(0, fset.size());
    t->add(1, 2, {-inf, 0});
    updateRem(0);

    // pall();

    forn(i, n) {
        add2(a[i]);
        // cerr << endl;

        // pall();
    }

    // cerr << valid.size() << endl;
    cout << t->get(fset[*valid.rbegin()]) << endl;
}

vector<pii> d;


void uin(i64& x, i64 y) { x = min(x, y); }

void restore() {
    vector<pii> nd;
    for (auto kv: d) {
        if (nd.empty() || kv.se < nd.back().se) {
            nd.push_back(kv);
        }
    }
    d = nd;
}

void addval(int y, i64 val) {
    auto it = lower_bound(all(d), pii{y, -1});
    if (it != d.end() && it->fi == y) {
        uin(it->se, val);
    } else {
        d.emplace(it, y, val);
    }
    restore();
}

void add(int y) {
    if (y > MM) {
        addval(MM, d.back().se);
        MM = y;
        return;
    }
    i64 best = inf;
    for (auto& kv: d) {
        if (kv.fi < y) {
            uin(best, kv.se);
            kv.se += MM - y;
        } else {
            kv.se += kv.fi - y;
        }
    }
    if (best < inf) {
        addval(y, best);
    } else {
        restore();
    }
}

void solve() {
    MM = 0;
    d = {{0,0}};
    forn(i, n) {
        // cerr << M << " ";
        // for (auto kv: d) cerr << kv << " ";
        // cerr << endl;
        add(a[i]);
    }
    // cerr << M << " ";
    // for (auto kv: d) cerr << kv << " ";
    // cerr << endl;
    cout << d.back().se << endl;
    cerr << d.size() << endl;
}

int main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif

    scan();
    solve2();

#ifdef LOCAL
    cerr << "Time elapsed: " << clock() / 1000 << " ms" << endl;
#endif
    return 0;
}

