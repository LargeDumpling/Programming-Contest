#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define fore(i, b, e) for (int i = (int)(b); i <= (int)(e); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define pb push_back
#define fi first
#define se second
#define all(x) (x).begin(), (x).end()
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long long i64;
typedef unsigned long long u64;
typedef long double ld;
typedef long long ll;

const int maxn = 10050;

int n;
int a[maxn];
int pot[maxn];
int sz[maxn];

void ask(int x) {
    cout << x << endl;
    string p;
    cin >> p;
    if (p == "End") {
        exit(0);
    }
    forn(i, n) {
        int t;
        cin >> t;
        if (t == 0) {
            pot[i] = 0;
            a[i] = 0;
            sz[i] = 0;
        } else if (a[i] == x || ((a[i] < x) == (p == "<="))) {
            a[i] = t;
            pot[i] /= 4;
            --sz[i];
        } else {
            assert(a[i] >= 1 && a[i] <= (int)1e9);
            assert(a[i] == t);
        }
    }
}

void ask_pot() {
    vector<pii> t;
    i64 p = 0;
    forn(i, n) if (a[i]) t.emplace_back(a[i], pot[i]), p += pot[i];
    sort(all(t));
    // i64 P = p;
    i64 p2 = p/2;
    for (auto kv: t) {
        p -= kv.second;
        if (p < p2) {
            // cerr << P << " = " << p+kv.se << " / " << P-p << endl;
            ask(kv.fi);
            return;
        }
    }
    assert(false);
}

int k;

void print() {
    int c[20] = {0};
    forn(i, n) c[sz[i]]++;
    forn(i, k+1) cerr << c[i] << "\t";
    cerr << endl;
}

void solve() {
    while (true) {
        ask_pot();
        print();
    }
}

int main() {
#ifdef LOCAL
    // freopen("input.txt", "r", stdin);
#endif

    cin >> n;
    cin >> k;
    forn(i, n) cin >> a[i], pot[i] = 1<<20, sz[i] = k;
    solve();

#ifdef LOCAL
    cerr << "Time elapsed: " << clock() / 1000 << " ms" << endl;
#endif
    return 0;
}
