#include <iostream>
#include <map>
#include <vector>
#include <list>
#include <fstream>
using namespace std;

const int MAX_L = 1000 * 1000 + 5;

int L;
string a, b;
vector<vector<int>> circles;
vector<bool> flag;
vector<bool> answer;
vector<bool> maybeAnswer;

void dfs(int v, vector<int>& circle) {
    if (flag[v]) {
        return;
    }
    flag[v] = true;
    circle.push_back(v);
    int next = (v % 2) ? ((L + v) / 2) : (v / 2);
    dfs(next, circle);
}

vector<int> z_function(const string& s) {
    vector<int> z (s.length());
    for (int i = 1, l = 0, r = 0; i < s.length(); ++i) {
        if (i <= r) {
            z[i] = min(r - i + 1, z[i - l]);
        }
        while (i + z[i] < s.length() && s[z[i]] == s[i + z[i]]) {
            z[i]++;
        }
        if (i + z[i] - 1 > r) {
            l = i;
            r = i + z[i] - 1;
        }
    }
    return z;
}


list<int> solve(const vector<int>& indexes) {
    string s;
    for (auto& index : indexes) {
        s.push_back(b[index]);
    }
    s.push_back('#');
    for (int i = 1; i <= 2; ++i) {
        for (auto& index : indexes) {
            s.push_back(a[index]);
        }
    }
    auto z = z_function(s);
    list<int> shifts;
    int length = indexes.size();
    z.erase(z.begin(), z.begin() + length + 1);
    for (int i = length - 1; i > 0; --i) {
        if (z[i] == length) {
            shifts.push_back(length - i);
        }
    }
    if (z[0] == length) {
        shifts.push_front(0);
    }
    shifts.push_back(length);       //!!!!!
    return shifts;
}

int main() {
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    cin >> a >> b;
    L = a.length();
    flag.assign(L, false);
    answer.assign(L, true);
    for (int i = 0; i < L; ++i) {
        if (!flag[i]) {
            circles.push_back(vector<int>());
            dfs(i, circles.back());
        }
    }
    
    map<int, list<int>> backets;
    for (int i = 0; i < circles.size(); ++i) {
        backets[circles[i].size()].push_back(i);
    }
    
    for (auto& backet : backets) {
        int length = backet.first;
        maybeAnswer.assign(length, true);
        for (auto& index : backet.second) {
            auto shifts = solve(circles[index]);
            auto it = shifts.begin();
            for (int i = 0; i < length && it != shifts.end(); ++i) {
                if (i != *it) {
                    maybeAnswer[i] = false;
                } else {
                    it++;
                }
            }
        }
        for (int i = 0; i < L; ++i) {
            if (!maybeAnswer[i % length]) {
                answer[i] = false;
            }
        }
    }
    for (int i = 0; i < L; ++i) {
        if (answer[i]) {
            cout << i << endl;
            return 0;
        }
    }
    cout << "-1" << endl;
    return 0;
}
