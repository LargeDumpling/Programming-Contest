#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define fore(i, b, e) for (int i = (int)(b); i <= (int)(e); ++i)
#define ford(i, n) for (int i = (int)(n) - 1; i >= 0; --i)
#define pb push_back
#define fi first
#define se second
#define all(x) (x).begin(), (x).end()
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef long long i64;
typedef unsigned long long u64;
typedef long double ld;
typedef long long ll;

const int maxn = 200500;

int n;
int allow[maxn];
int a[maxn];
int lbl[maxn];
int cnt[maxn];
vi even, odd;
int xx;

const int M = 1 << 20;
const int M2 = 1 << 25;

void fillEven() {
    forn(i, even.size()) lbl[even[i]] = M2 + i;
}

void fillOdd(vi a) {
    assert(a.size() == odd.size());
    forn(i, odd.size()) lbl[odd[i]] = a[i];
}

void no() {
    cout << -1 << endl;
    exit(0);
}

void print() {
    cout << n/2+1 << endl;
    forn(i, n) cout << lbl[a[i]] << " \n"[i%2];
}

void zero(vi& a, int n, int m) {
    assert(m%4 == 0);
    if (n == 0) return;
    assert(n > 2);
    if (n == 3) {
        a.push_back(M * 2);
        a.push_back(M * 4);
        a.push_back(M * 6);
        return;
    }
    if (n == 6) {
        a.push_back(M * 2);
        a.push_back(M * 4);
        a.push_back(M * 6);
        a.push_back(M * 3);
        a.push_back(M * 8);
        a.push_back(M * 11);
        return;
    }
    if (n == 5) {
        a.push_back(2 * M * 1);
        a.push_back(2 * M * 2);
        a.push_back(2 * M * 6);
        a.push_back(2 * M * 11);
        a.push_back(2 * M * 14);
        return;
    }
    forn(i, 4) a.push_back(m+i);
    zero(a, n-4, m+4);
}

int main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif

    cin >> n;
    fore(i, 1, n) {
        cin >> allow[i];
        if (!allow[i]) lbl[i] = i;
    }
    xx = n;
    n = n * 2 - 2;
    forn(i, n) {
        cin >> a[i];
        int x = a[i];
        if (allow[x]) ++cnt[x];
        else xx ^= x;
    }
    fore(i, 1, n/2+1) if (allow[i]) {
        if (cnt[i] % 2) odd.push_back(i);
        else even.push_back(i);
    }

    int p = odd.size();

    fillEven();

    if (p == 0) {
        if (xx != 0) no();
        print();
    } else if (p == 1) {
        if (1 <= xx && xx <= n/2+1 && !allow[xx]) no();
        if (xx == 0 || xx > (int)1e9) no();
        lbl[odd[0]] = xx;
        print();
    } else {
        if (p == 2 && xx == 0) no();
        vi a;
        if (xx == 0) zero(a, p, maxn);
        else if (p == 2) a = { M, M ^ xx };
        else if (p == 3) a = { M, 2 * M, (3 * M) ^ xx };
        else if (p == 4) a = { M * 4, M * 5, M * 6, (M * 7) ^ xx };
        else {
            a = {M, M ^ xx};
            zero(a, p - 2, maxn);
        }
        fillOdd(a);
        print();
    }


#ifdef LOCAL
    cerr << "Time elapsed: " << clock() / 1000 << " ms" << endl;
#endif
    return 0;
}
